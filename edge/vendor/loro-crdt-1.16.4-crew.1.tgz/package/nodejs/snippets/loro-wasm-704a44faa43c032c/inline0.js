var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var inline0_exports = {};
__export(inline0_exports, {
  stateBinary: () => stateBinary,
  stateCid: () => stateCid,
  stateContainer: () => stateContainer,
  stateIndex: () => stateIndex,
  stateOptions: () => stateOptions,
  stateRootCid: () => stateRootCid,
  stateSet: () => stateSet,
  stateSlice: () => stateSlice,
  stateValue: () => stateValue
});
module.exports = __toCommonJS(inline0_exports);
const kinds = ["Map", "List", "MovableList", "Text", "Tree", "Counter"];
function stateOptions(options, document) {
  if (typeof options !== "object" || options === null || Array.isArray(options)) throw new Error("Invalid toContainerTree options");
  for (const key of Object.keys(options)) {
    if (key !== "text" && !(document && key === "roots")) throw new Error("Unknown toContainerTree option: " + key);
  }
  if (document && options.roots !== void 0 && !Array.isArray(options.roots)) throw new Error("roots must be an array");
  return options;
}
function stateSlice(node, start, totalLength) {
  return { cid: node.cid, start, totalLength, items: node.value };
}
function stateContainer(kind, cid, value) {
  return { type: kinds[kind], cid, value };
}
function stateCid(peer, counter, kind) {
  return "cid:" + counter + "@" + peer + ":" + kinds[kind];
}
function stateRootCid(name, kind) {
  return "cid:root-" + name + ":" + kinds[kind];
}
function stateValue(value) {
  return { type: "Value", value };
}
function stateBinary(bytes) {
  return bytes.slice();
}
function stateIndex(array, index, value) {
  Object.defineProperty(array, index, { value, enumerable: true, writable: true, configurable: true });
}
function stateSet(object, key, value) {
  Object.defineProperty(object, key, { value, enumerable: true, writable: true, configurable: true });
}
