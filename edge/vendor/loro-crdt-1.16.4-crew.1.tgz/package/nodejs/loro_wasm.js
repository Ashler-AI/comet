
let imports = {};
imports['./snippets/loro-wasm-704a44faa43c032c/inline0.js'] = require('./snippets/loro-wasm-704a44faa43c032c/inline0.js');
imports['__wbindgen_placeholder__'] = module.exports;
let wasm;
const { stateBinary, stateIndex, stateOptions, stateRootCid, stateSet, stateSlice } = require(String.raw`./snippets/loro-wasm-704a44faa43c032c/inline0.js`);
const { TextEncoder, TextDecoder } = require(`util`);

let WASM_VECTOR_LEN = 0;

let cachedUint8ArrayMemory0 = null;

function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

let cachedTextEncoder = new TextEncoder('utf-8');

const encodeString = (typeof cachedTextEncoder.encodeInto === 'function'
    ? function (arg, view) {
    return cachedTextEncoder.encodeInto(arg, view);
}
    : function (arg, view) {
    const buf = cachedTextEncoder.encode(arg);
    view.set(buf);
    return {
        read: arg.length,
        written: buf.length
    };
});

function passStringToWasm0(arg, malloc, realloc) {

    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }

    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = encodeString(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

let cachedDataViewMemory0 = null;

function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

function addToExternrefTable0(obj) {
    const idx = wasm.__externref_table_alloc();
    wasm.__wbindgen_export_4.set(idx, obj);
    return idx;
}

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        const idx = addToExternrefTable0(e);
        wasm.__wbindgen_exn_store(idx);
    }
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });

cachedTextDecoder.decode();

function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

const CLOSURE_DTORS = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(state => {
    wasm.__wbindgen_export_6.get(state.dtor)(state.a, state.b)
});

function makeMutClosure(arg0, arg1, dtor, f) {
    const state = { a: arg0, b: arg1, cnt: 1, dtor };
    const real = (...args) => {
        // First up with a closure we increment the internal reference
        // count. This ensures that the Rust closure environment won't
        // be deallocated while we're invoking it.
        state.cnt++;
        const a = state.a;
        state.a = 0;
        try {
            return f(a, state.b, ...args);
        } finally {
            if (--state.cnt === 0) {
                wasm.__wbindgen_export_6.get(state.dtor)(a, state.b);
                CLOSURE_DTORS.unregister(state);
            } else {
                state.a = a;
            }
        }
    };
    real.original = state;
    CLOSURE_DTORS.register(real, state, state);
    return real;
}

function debugString(val) {
    // primitive types
    const type = typeof val;
    if (type == 'number' || type == 'boolean' || val == null) {
        return  `${val}`;
    }
    if (type == 'string') {
        return `"${val}"`;
    }
    if (type == 'symbol') {
        const description = val.description;
        if (description == null) {
            return 'Symbol';
        } else {
            return `Symbol(${description})`;
        }
    }
    if (type == 'function') {
        const name = val.name;
        if (typeof name == 'string' && name.length > 0) {
            return `Function(${name})`;
        } else {
            return 'Function';
        }
    }
    // objects
    if (Array.isArray(val)) {
        const length = val.length;
        let debug = '[';
        if (length > 0) {
            debug += debugString(val[0]);
        }
        for(let i = 1; i < length; i++) {
            debug += ', ' + debugString(val[i]);
        }
        debug += ']';
        return debug;
    }
    // Test for built-in
    const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
    let className;
    if (builtInMatches && builtInMatches.length > 1) {
        className = builtInMatches[1];
    } else {
        // Failed to match the standard '[object ClassName]'
        return toString.call(val);
    }
    if (className == 'Object') {
        // we're a user defined class or Object
        // JSON.stringify avoids problems with cycles, and is generally much
        // easier than looping through ownProperties of `val`.
        try {
            return 'Object(' + JSON.stringify(val) + ')';
        } catch (_) {
            return 'Object';
        }
    }
    // errors
    if (val instanceof Error) {
        return `${val.name}: ${val.message}\n${val.stack}`;
    }
    // TODO we could test for more things here, like `Set`s and `Map`s.
    return className;
}
/**
 * Get the version of Loro
 * @returns {string}
 */
module.exports.LORO_VERSION = function() {
    let deferred1_0;
    let deferred1_1;
    try {
        const ret = wasm.LORO_VERSION();
        deferred1_0 = ret[0];
        deferred1_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
};

function passArray8ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 1, 1) >>> 0;
    getUint8ArrayMemory0().set(arg, ptr / 1);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_export_4.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}
/**
 * Decode the metadata of the import blob.
 *
 * This method is useful to get the following metadata of the import blob:
 *
 * - startVersionVector
 * - endVersionVector
 * - startTimestamp
 * - endTimestamp
 * - mode
 * - changeNum
 * @param {Uint8Array} blob
 * @param {boolean} check_checksum
 * @returns {ImportBlobMetadata}
 */
module.exports.decodeImportBlobMeta = function(blob, check_checksum) {
    const ptr0 = passArray8ToWasm0(blob, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.decodeImportBlobMeta(ptr0, len0, check_checksum);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
};

module.exports.callPendingEvents = function() {
    wasm.callPendingEvents();
};

/**
 * Redacts sensitive content in JSON updates within the specified version range.
 *
 * This function allows you to share document history while removing potentially sensitive content.
 * It preserves the document structure and collaboration capabilities while replacing content with
 * placeholders according to these redaction rules:
 *
 * - Preserves delete and move operations
 * - Replaces text insertion content with the Unicode replacement character
 * - Substitutes list and map insert values with null
 * - Maintains structure of child containers
 * - Replaces text mark values with null
 * - Preserves map keys and text annotation keys
 *
 * @param {Object|string} jsonUpdates - The JSON updates to redact (object or JSON string)
 * @param {Object} versionRange - Version range defining what content to redact,
 *                  format: { peerId: [startCounter, endCounter], ... }
 * @returns {Object} The redacted JSON updates
 * @param {string | JsonSchema} json_updates
 * @param {any} version_range
 * @returns {JsonSchema}
 */
module.exports.redactJsonUpdates = function(json_updates, version_range) {
    const ret = wasm.redactJsonUpdates(json_updates, version_range);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
};

/**
 * Returns whether `value` is a syntactically valid container ID.
 * @param {string} value
 * @returns {boolean}
 */
module.exports.isValidContainerId = function(value) {
    const ptr0 = passStringToWasm0(value, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.isValidContainerId(ptr0, len0);
    return ret !== 0;
};

module.exports.run = function() {
    wasm.run();
};

function passArrayJsValueToWasm0(array, malloc) {
    const ptr = malloc(array.length * 4, 4) >>> 0;
    for (let i = 0; i < array.length; i++) {
        const add = addToExternrefTable0(array[i]);
        getDataViewMemory0().setUint32(ptr + 4 * i, add, true);
    }
    WASM_VECTOR_LEN = array.length;
    return ptr;
}
/**
 * @param {({ peer: PeerID, counter: number })[]} frontiers
 * @returns {Uint8Array}
 */
module.exports.encodeFrontiers = function(frontiers) {
    const ptr0 = passArrayJsValueToWasm0(frontiers, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.encodeFrontiers(ptr0, len0);
    if (ret[3]) {
        throw takeFromExternrefTable0(ret[2]);
    }
    var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
    wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
    return v2;
};

/**
 * @param {Uint8Array} bytes
 * @returns {{ peer: PeerID, counter: number }[]}
 */
module.exports.decodeFrontiers = function(bytes) {
    const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.decodeFrontiers(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
};

/**
 * Enable debug info of Loro
 */
module.exports.setDebug = function() {
    wasm.setDebug();
};

function _assertClass(instance, klass) {
    if (!(instance instanceof klass)) {
        throw new Error(`expected instance of ${klass.name}`);
    }
}

function getArrayJsValueFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    const mem = getDataViewMemory0();
    const result = [];
    for (let i = ptr; i < ptr + 4 * len; i += 4) {
        result.push(wasm.__wbindgen_export_4.get(mem.getUint32(i, true)));
    }
    wasm.__externref_drop_slice(ptr, len);
    return result;
}
function __wbg_adapter_60(arg0, arg1, arg2) {
    wasm.closure159_externref_shim(arg0, arg1, arg2);
}

function __wbg_adapter_63(arg0, arg1) {
    wasm._dyn_core_9b3796e30d99ddb7___ops__function__FnMut_____Output______as_wasm_bindgen_b305d52f4c18ec15___closure__WasmClosure___describe__invoke______(arg0, arg1);
}

const AwarenessWasmFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_awarenesswasm_free(ptr >>> 0, 1));
/**
 * `Awareness` is a structure that tracks the ephemeral state of peers.
 *
 * It can be used to synchronize cursor positions, selections, and the names of the peers.
 *
 * The state of a specific peer is expected to be removed after a specified timeout. Use
 * `remove_outdated` to eliminate outdated states.
 */
class AwarenessWasm {

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        AwarenessWasmFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_awarenesswasm_free(ptr, 0);
    }
    /**
     * Get the state of all peers.
     * @returns {{[peer in PeerID]: unknown}}
     */
    getAllStates() {
        const ret = wasm.awarenesswasm_getAllStates(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the timestamp of the state of a given peer.
     * @param {number | bigint | `${number}`} peer
     * @returns {number | undefined}
     */
    getTimestamp(peer) {
        const ret = wasm.awarenesswasm_getTimestamp(this.__wbg_ptr, peer);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        return ret[0] === 0 ? undefined : ret[1];
    }
    /**
     * Sets the state of the local peer.
     * @param {any} value
     */
    setLocalState(value) {
        wasm.awarenesswasm_setLocalState(this.__wbg_ptr, value);
    }
    /**
     * Remove the states of outdated peers.
     * @returns {PeerID[]}
     */
    removeOutdated() {
        const ret = wasm.awarenesswasm_removeOutdated(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Creates a new `Awareness` instance.
     *
     * The `timeout` parameter specifies the duration in milliseconds.
     * A state of a peer is considered outdated, if the last update of the state of the peer
     * is older than the `timeout`.
     * @param {number | bigint | `${number}`} peer
     * @param {number} timeout
     */
    constructor(peer, timeout) {
        const ret = wasm.awarenesswasm_new(peer, timeout);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0] >>> 0;
        AwarenessWasmFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Get the PeerID of the local peer.
     * @returns {PeerID}
     */
    peer() {
        const ret = wasm.awarenesswasm_peer(this.__wbg_ptr);
        return ret;
    }
    /**
     * Applies the encoded state of peers.
     *
     * Each peer's deletion countdown will be reset upon update, requiring them to pass through the `timeout`
     * interval again before being eligible for deletion.
     * @param {Uint8Array} encoded_peers_info
     * @returns {{ updated: PeerID[], added: PeerID[] }}
     */
    apply(encoded_peers_info) {
        const ptr0 = passArray8ToWasm0(encoded_peers_info, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.awarenesswasm_apply(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get all the peers
     * @returns {PeerID[]}
     */
    peers() {
        const ret = wasm.awarenesswasm_peers(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Encodes the state of the given peers.
     * @param {Array<any>} peers
     * @returns {Uint8Array}
     */
    encode(peers) {
        const ret = wasm.awarenesswasm_encode(this.__wbg_ptr, peers);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * Get the number of peers.
     * @returns {number}
     */
    length() {
        const ret = wasm.awarenesswasm_length(this.__wbg_ptr);
        return ret;
    }
    /**
     * If the state is empty.
     * @returns {boolean}
     */
    isEmpty() {
        const ret = wasm.awarenesswasm_isEmpty(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Get the state of a given peer.
     * @param {number | bigint | `${number}`} peer
     * @returns {any}
     */
    getState(peer) {
        const ret = wasm.awarenesswasm_getState(this.__wbg_ptr, peer);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Encodes the state of all peers.
     * @returns {Uint8Array}
     */
    encodeAll() {
        const ret = wasm.awarenesswasm_encodeAll(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
}
module.exports.AwarenessWasm = AwarenessWasm;

const ChangeModifierFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_changemodifier_free(ptr >>> 0, 1));

class ChangeModifier {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(ChangeModifier.prototype);
        obj.__wbg_ptr = ptr;
        ChangeModifierFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ChangeModifierFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_changemodifier_free(ptr, 0);
    }
    /**
     * @param {string} message
     * @returns {ChangeModifier}
     */
    setMessage(message) {
        const ptr0 = passStringToWasm0(message, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.changemodifier_setMessage(this.__wbg_ptr, ptr0, len0);
        return ChangeModifier.__wrap(ret);
    }
    /**
     * @param {number} timestamp
     * @returns {ChangeModifier}
     */
    setTimestamp(timestamp) {
        const ret = wasm.changemodifier_setTimestamp(this.__wbg_ptr, timestamp);
        return ChangeModifier.__wrap(ret);
    }
}
module.exports.ChangeModifier = ChangeModifier;

const CursorFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_cursor_free(ptr >>> 0, 1));
/**
 * Cursor is a stable position representation in the doc.
 * When expressing the position of a cursor, using "index" can be unstable
 * because the cursor's position may change due to other deletions and insertions,
 * requiring updates with each edit. To stably represent a position or range within
 * a list structure, we can utilize the ID of each item/character on List CRDT or
 * Text CRDT for expression.
 *
 * Loro optimizes State metadata by not storing the IDs of deleted elements. This
 * approach complicates tracking cursors since they rely on these IDs. The solution
 * recalculates position by replaying relevant history to update cursors
 * accurately. To minimize the performance impact of history replay, the system
 * updates cursor info to reference only the IDs of currently present elements,
 * thereby reducing the need for replay.
 *
 * @example
 * ```ts
 *
 * const doc = new LoroDoc();
 * const text = doc.getText("text");
 * text.insert(0, "123");
 * const pos0 = text.getCursor(0, 0);
 * {
 *   const ans = doc.getCursorPos(pos0!);
 *   expect(ans.offset).toBe(0);
 * }
 * text.insert(0, "1");
 * {
 *   const ans = doc.getCursorPos(pos0!);
 *   expect(ans.offset).toBe(1);
 * }
 * ```
 */
class Cursor {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(Cursor.prototype);
        obj.__wbg_ptr = ptr;
        CursorFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        CursorFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_cursor_free(ptr, 0);
    }
    /**
     * Get the id of the given container.
     * @returns {ContainerID}
     */
    containerId() {
        const ret = wasm.cursor_containerId(this.__wbg_ptr);
        return ret;
    }
    /**
     * Get the ID that represents the position.
     *
     * It can be undefined if it's not bind into a specific ID.
     * @returns {{ peer: PeerID, counter: number } | undefined}
     */
    pos() {
        const ret = wasm.cursor_pos(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * "Cursor"
     * @returns {any}
     */
    kind() {
        const ret = wasm.cursor_kind(this.__wbg_ptr);
        return ret;
    }
    /**
     * Get which side of the character/list item the cursor is on.
     * @returns {Side}
     */
    side() {
        const ret = wasm.cursor_side(this.__wbg_ptr);
        return ret;
    }
    /**
     * Decode the cursor from a Uint8Array.
     * @param {Uint8Array} data
     * @returns {Cursor}
     */
    static decode(data) {
        const ptr0 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.cursor_decode(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return Cursor.__wrap(ret[0]);
    }
    /**
     * Encode the cursor into a Uint8Array.
     * @returns {Uint8Array}
     */
    encode() {
        const ret = wasm.cursor_encode(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
}
module.exports.Cursor = Cursor;

const EphemeralStoreWasmFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_ephemeralstorewasm_free(ptr >>> 0, 1));

class EphemeralStoreWasm {

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        EphemeralStoreWasmFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_ephemeralstorewasm_free(ptr, 0);
    }
    /**
     * @returns {any}
     */
    getAllStates() {
        const ret = wasm.ephemeralstorewasm_getAllStates(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    removeOutdated() {
        wasm.ephemeralstorewasm_removeOutdated(this.__wbg_ptr);
    }
    /**
     * @param {Function} f
     * @returns {any}
     */
    subscribeLocalUpdates(f) {
        const ret = wasm.ephemeralstorewasm_subscribeLocalUpdates(this.__wbg_ptr, f);
        return ret;
    }
    /**
     * @param {string} key
     * @returns {any}
     */
    get(key) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.ephemeralstorewasm_get(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Creates a new `EphemeralStore` instance.
     *
     * The `timeout` parameter specifies the duration in milliseconds.
     * A state of a peer is considered outdated, if the last update of the state of the peer
     * is older than the `timeout`.
     * @param {number} timeout
     */
    constructor(timeout) {
        const ret = wasm.ephemeralstorewasm_new(timeout);
        this.__wbg_ptr = ret >>> 0;
        EphemeralStoreWasmFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * @param {string} key
     * @param {any} value
     */
    set(key, value) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.ephemeralstorewasm_set(this.__wbg_ptr, ptr0, len0, value);
    }
    /**
     * @returns {string[]}
     */
    keys() {
        const ret = wasm.ephemeralstorewasm_keys(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * @param {Uint8Array} data
     */
    apply(data) {
        const ptr0 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.ephemeralstorewasm_apply(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} key
     */
    delete(key) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.ephemeralstorewasm_delete(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {string} key
     * @returns {Uint8Array}
     */
    encode(key) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.ephemeralstorewasm_encode(this.__wbg_ptr, ptr0, len0);
        var v2 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v2;
    }
    /**
     * If the state is empty.
     * @returns {boolean}
     */
    isEmpty() {
        const ret = wasm.ephemeralstorewasm_isEmpty(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {Uint8Array}
     */
    encodeAll() {
        const ret = wasm.ephemeralstorewasm_encodeAll(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * @param {Function} f
     * @returns {any}
     */
    subscribe(f) {
        const ret = wasm.ephemeralstorewasm_subscribe(this.__wbg_ptr, f);
        return ret;
    }
}
module.exports.EphemeralStoreWasm = EphemeralStoreWasm;

const LoroCounterFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_lorocounter_free(ptr >>> 0, 1));
/**
 * The handler of a counter container.
 */
class LoroCounter {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(LoroCounter.prototype);
        obj.__wbg_ptr = ptr;
        LoroCounterFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        LoroCounterFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_lorocounter_free(ptr, 0);
    }
    /**
     * Whether the container is attached to a docuemnt.
     *
     * If it's detached, the operations on the container will not be persisted.
     * @returns {boolean}
     */
    isAttached() {
        const ret = wasm.lorocounter_isAttached(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Get the attached container associated with this.
     *
     * Returns an attached `Container` that equals to this or created by this, otherwise `undefined`.
     * @returns {LoroTree | undefined}
     */
    getAttached() {
        const ret = wasm.lorocounter_getAttached(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the value of the counter.
     * @returns {number}
     */
    getShallowValue() {
        const ret = wasm.lorocounter_getShallowValue(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0];
    }
    /**
     * The container id of this handler.
     * @returns {ContainerID}
     */
    get id() {
        const ret = wasm.lorocounter_id(this.__wbg_ptr);
        return ret;
    }
    /**
     * Create a new LoroCounter.
     */
    constructor() {
        const ret = wasm.lorocounter_new();
        this.__wbg_ptr = ret >>> 0;
        LoroCounterFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * "Counter"
     * @returns {'Counter'}
     */
    kind() {
        const ret = wasm.lorocounter_kind(this.__wbg_ptr);
        return ret;
    }
    /**
     * Get the parent container of the counter container.
     *
     * - The parent container of the root counter is `undefined`.
     * - The object returned is a new js object each time because it need to cross
     *   the WASM boundary.
     * @returns {Container | undefined}
     */
    parent() {
        const ret = wasm.lorocounter_parent(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {number}
     */
    toJSON() {
        const ret = wasm.lorocounter_toJSON(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0];
    }
    /**
     * Decrement the counter by the given value.
     * @param {number} value
     */
    decrement(value) {
        const ret = wasm.lorocounter_decrement(this.__wbg_ptr, value);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Get the value of the counter.
     * @returns {number}
     */
    get value() {
        const ret = wasm.lorocounter_value(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0];
    }
    /**
     * Increment the counter by the given value.
     * @param {number} value
     */
    increment(value) {
        const ret = wasm.lorocounter_increment(this.__wbg_ptr, value);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Subscribe to the changes of the counter.
     * @param {Function} f
     * @returns {any}
     */
    subscribe(f) {
        const ret = wasm.lorocounter_subscribe(this.__wbg_ptr, f);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Convert this attached container and all descendants to an independent tree.
     * Text format applies recursively. Does not commit; throws for detached
     * containers, unsupported types, invalid options, or nesting above 256.
     * @param {ContainerTreeOptions | null} [opts]
     * @returns {ContainerNode}
     */
    toContainerTree(opts) {
        const ret = wasm.lorocounter_toContainerTree(this.__wbg_ptr, isLikeNone(opts) ? 0 : addToExternrefTable0(opts));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
module.exports.LoroCounter = LoroCounter;

const LoroDocFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_lorodoc_free(ptr >>> 0, 1));
/**
 * The CRDTs document. Loro supports different CRDTs include [**List**](LoroList),
 * [**RichText**](LoroText), [**Map**](LoroMap) and [**Movable Tree**](LoroTree),
 * you could build all kind of applications by these.
 *
 * **Important:** Loro is a pure library and does not handle network protocols.
 * It is the responsibility of the user to manage the storage, loading, and synchronization
 * of the bytes exported by Loro in a manner suitable for their specific environment.
 *
 * @example
 * ```ts
 * import { LoroDoc } from "loro-crdt"
 *
 * const loro = new LoroDoc();
 * const text = loro.getText("text");
 * const list = loro.getList("list");
 * const map = loro.getMap("Map");
 * const tree = loro.getTree("tree");
 * ```
 */
class LoroDoc {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(LoroDoc.prototype);
        obj.__wbg_ptr = ptr;
        LoroDocFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        LoroDocFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_lorodoc_free(ptr, 0);
    }
    /**
     * Apply a batch of diff to the document
     *
     * A diff batch represents a set of changes between two versions of the document.
     * You can calculate a diff batch using `doc.diff()`.
     *
     * Changes are associated with container IDs. During diff application, if new containers were created in the source
     * document, they will be assigned fresh IDs in the target document. Loro automatically handles remapping these
     * container IDs from their original IDs to the new IDs as the diff is applied.
     *
     * @example
     * ```ts
     * const doc1 = new LoroDoc();
     * const doc2 = new LoroDoc();
     *
     * // Make some changes to doc1
     * const text = doc1.getText("text");
     * text.insert(0, "Hello");
     *
     * // Calculate diff between empty and current state
     * const diff = doc1.diff([], doc1.frontiers());
     *
     * // Apply changes to doc2
     * doc2.applyDiff(diff);
     * console.log(doc2.getText("text").toString()); // "Hello"
     * ```
     *
     * Pass `{ fullState: true }` when applying the result of `doc.diff()` to a document that may
     * keep hidden state for a mergeable child the diff makes visible again (e.g. applying
     * `doc.diff(afterDelete, beforeDelete)` to `doc` itself or to a copy of it). The child's
     * entry is then read as its full content and aligned with that hidden state. Without it
     * (the default), entries are applied as increments, which is right for events forwarded to
     * a document that shares the source's hidden state. Never pass it for events from local
     * commits; see `ApplyDiffOptions.fullState`.
     *
     * ```ts
     * const text = doc.getMap("m").ensureMergeableText("t");
     * text.insert(0, "hello");
     * const before = doc.frontiers();
     * doc.getMap("m").delete("t");
     * doc.applyDiff(doc.diff(doc.frontiers(), before), { fullState: true });
     * console.log(doc.getMap("m").get("t").toString()); // "hello"
     * ```
     * @param {[ContainerID, Diff|JsonDiff][]} diff
     * @param {ApplyDiffOptions | null} [options]
     */
    applyDiff(diff, options) {
        const ret = wasm.lorodoc_applyDiff(this.__wbg_ptr, diff, isLikeNone(options) ? 0 : addToExternrefTable0(options));
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Check if the doc contains the full history.
     * @returns {boolean}
     */
    isShallow() {
        const ret = wasm.lorodoc_isShallow(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Get the number of changes in the oplog.
     * @returns {number}
     */
    changeCount() {
        const ret = wasm.lorodoc_changeCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Get the value or container at the given path
     *
     * The path can be specified in different ways depending on the container type:
     *
     * For Tree:
     * 1. Using node IDs: `tree/{node_id}/property`
     * 2. Using indices: `tree/0/1/property`
     *
     * For List and MovableList:
     * - Using indices: `list/0` or `list/1/property`
     *
     * For Map:
     * - Using keys: `map/key` or `map/nested/property`
     *
     * For tree structures, index-based paths follow depth-first traversal order.
     * The indices start from 0 and represent the position of a node among its siblings.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const map = doc.getMap("map");
     * map.set("key", 1);
     * console.log(doc.getByPath("map/key")); // 1
     * console.log(doc.getByPath("map"));     // LoroMap
     * ```
     * @param {string} path
     * @returns {Value | Container | undefined}
     */
    getByPath(path) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.lorodoc_getByPath(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get a LoroCounter by container id
     *
     * If the container does not exist, an error will be thrown.
     * @param {ContainerID | string} cid
     * @returns {LoroCounter}
     */
    getCounter(cid) {
        const ret = wasm.lorodoc_getCounter(this.__wbg_ptr, cid);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return LoroCounter.__wrap(ret[0]);
    }
    /**
     * `detached` indicates that the `DocState` is not synchronized with the latest version of `OpLog`.
     *
     * > The document becomes detached during a `checkout` operation.
     * > Being `detached` implies that the `DocState` is not synchronized with the latest version of the `OpLog`.
     * > In a detached state, the document is not editable by default, and any `import` operations will be
     * > recorded in the `OpLog` without being applied to the `DocState`.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * const frontiers = doc.frontiers();
     * text.insert(0, "Hello World!");
     * console.log(doc.isDetached());  // false
     * doc.checkout(frontiers);
     * console.log(doc.isDetached());  // true
     * doc.attach();
     * console.log(doc.isDetached());  // false
     * ```
     * @returns {boolean}
     */
    isDetached() {
        const ret = wasm.lorodoc_isDetached(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Get peer id in decimal string.
     * @returns {PeerID}
     */
    get peerIdStr() {
        const ret = wasm.lorodoc_peerIdStr(this.__wbg_ptr);
        return ret;
    }
    /**
     * Set the peer ID of the current writer.
     *
     * It must be a number, a BigInt, or a decimal string that can be parsed to a unsigned 64-bit integer.
     *
     * Note: use it with caution. You need to make sure there is not chance that two peers
     * have the same peer ID. Otherwise, we cannot ensure the consistency of the document.
     * @param {number | bigint | `${number}`} peer_id
     */
    setPeerId(peer_id) {
        const ret = wasm.lorodoc_setPeerId(this.__wbg_ptr, peer_id);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Get the absolute position of the given Cursor
     *
     * @example
     * ```ts
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * text.insert(0, "123");
     * const pos0 = text.getCursor(0, 0);
     * {
     *    const ans = doc.getCursorPos(pos0!);
     *    expect(ans.offset).toBe(0);
     * }
     * text.insert(0, "1");
     * {
     *    const ans = doc.getCursorPos(pos0!);
     *    expect(ans.offset).toBe(1);
     * }
     * ```
     * @param {Cursor} cursor
     * @returns {{ update?: Cursor, offset: number, side: Side } | undefined}
     */
    getCursorPos(cursor) {
        _assertClass(cursor, Cursor);
        const ret = wasm.lorodoc_getCursorPos(this.__wbg_ptr, cursor.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Check if the doc contains the target container.
     *
     * A root container always exists, while a normal container exists
     * if it has ever been created on the doc.
     *
     * @example
     * ```ts
     * import { LoroDoc, LoroMap, LoroText, LoroList } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * doc.setPeerId("1");
     * const text = doc.getMap("map").setContainer("text", new LoroText());
     * const list = doc.getMap("map").setContainer("list", new LoroList());
     * expect(doc.isContainerExists("cid:root-map:Map")).toBe(true);
     * expect(doc.isContainerExists("cid:0@1:Text")).toBe(true);
     * expect(doc.isContainerExists("cid:1@1:List")).toBe(true);
     *
     * const doc2 = new LoroDoc();
     * // Containers exist, as long as the history or the doc state include it
     * doc.detach();
     * doc2.import(doc.export({ mode: "update" }));
     * expect(doc2.isContainerExists("cid:root-map:Map")).toBe(true);
     * expect(doc2.isContainerExists("cid:0@1:Text")).toBe(true);
     * expect(doc2.isContainerExists("cid:1@1:List")).toBe(true);
     * ```
     * @param {ContainerID} container_id
     * @returns {boolean}
     */
    hasContainer(container_id) {
        const ret = wasm.lorodoc_hasContainer(this.__wbg_ptr, container_id);
        return ret !== 0;
    }
    /**
     * Import a batch of updates or snapshots.
     *
     * It's more efficient than importing updates one by one.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * text.insert(0, "Hello");
     * const updates = doc.export({ mode: "update" });
     * const snapshot = doc.export({ mode: "snapshot" });
     * const doc2 = new LoroDoc();
     * doc2.importBatch([snapshot, updates]);
     * ```
     * @param {Uint8Array[]} data
     * @returns {ImportStatus}
     */
    importBatch(data) {
        const ret = wasm.lorodoc_importBatch(this.__wbg_ptr, data);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Compare the ordering of two Frontiers.
     *
     * It's assumed that both Frontiers are included by the doc. Otherwise, an error will be thrown.
     *
     * Return value:
     *
     * - -1: a < b
     * - 0: a == b
     * - 1: a > b
     * - undefined: a ∥ b: a and b are concurrent
     * @param {({ peer: PeerID, counter: number })[]} a
     * @param {({ peer: PeerID, counter: number })[]} b
     * @returns {-1 | 1 | 0 | undefined}
     */
    cmpFrontiers(a, b) {
        const ptr0 = passArrayJsValueToWasm0(a, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArrayJsValueToWasm0(b, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.lorodoc_cmpFrontiers(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Debug the size of the history
     */
    debugHistory() {
        wasm.lorodoc_debugHistory(this.__wbg_ptr);
    }
    /**
     * Create a loro document from the snapshot.
     *
     * @see You can learn more [here](https://loro.dev/docs/tutorial/encoding).
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt"
     *
     * const doc = new LoroDoc();
     * // ...
     * const bytes = doc.export({ mode: "snapshot" });
     * const loro = LoroDoc.fromSnapshot(bytes);
     * ```
     * @param {Uint8Array} snapshot
     * @returns {LoroDoc}
     */
    static fromSnapshot(snapshot) {
        const ptr0 = passArray8ToWasm0(snapshot, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.lorodoc_fromSnapshot(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return LoroDoc.__wrap(ret[0]);
    }
    /**
     * Get the change that contains the specific ID
     * @param {{ peer: PeerID, counter: number }} id
     * @returns {Change}
     */
    getChangeAt(id) {
        const ret = wasm.lorodoc_getChangeAt(this.__wbg_ptr, id);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the version vector of the latest known version in OpLog.
     *
     * If you checkout to a specific version, this version vector will not change.
     * @returns {VersionVector}
     */
    oplogVersion() {
        const ret = wasm.lorodoc_oplogVersion(this.__wbg_ptr);
        return VersionVector.__wrap(ret);
    }
    /**
     * Get a LoroMovableList by container id
     *
     * The object returned is a new js object each time because it need to cross
     * the WASM boundary.
     *
     * If the container does not exist, an error will be thrown.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getMovableList("list");
     * ```
     * @param {ContainerID | string} cid
     * @returns {LoroMovableList}
     */
    getMovableList(cid) {
        const ret = wasm.lorodoc_getMovableList(this.__wbg_ptr, cid);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return LoroMovableList.__wrap(ret[0]);
    }
    /**
     * Convert frontiers to a version vector
     *
     * Learn more about frontiers and version vector [here](https://loro.dev/docs/advanced/version_deep_dive)
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * text.insert(0, "Hello");
     * const frontiers = doc.frontiers();
     * const version = doc.frontiersToVV(frontiers);
     * ```
     * @param {({ peer: PeerID, counter: number })[]} frontiers
     * @returns {VersionVector}
     */
    frontiersToVV(frontiers) {
        const ptr0 = passArrayJsValueToWasm0(frontiers, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.lorodoc_frontiersToVV(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return VersionVector.__wrap(ret[0]);
    }
    /**
     * Get all of changes in the oplog.
     *
     * Note: this method is expensive when the oplog is large. O(n)
     *
     * @example
     * ```ts
     * import { LoroDoc, LoroText } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * text.insert(0, "Hello");
     * const changes = doc.getAllChanges();
     *
     * for (let [peer, c] of changes.entries()){
     *     console.log("peer: ", peer);
     *     for (let change of c){
     *         console.log("change: ", change);
     *     }
     * }
     * ```
     * @returns {Map<PeerID, Change[]>}
     */
    getAllChanges() {
        const ret = wasm.lorodoc_getAllChanges(this.__wbg_ptr);
        return ret;
    }
    /**
     * Get the [frontiers](https://loro.dev/docs/advanced/version_deep_dive) of the latest version in OpLog.
     *
     * If you checkout to a specific version, this value will not change.
     * @returns {{ peer: PeerID, counter: number }[]}
     */
    oplogFrontiers() {
        const ret = wasm.lorodoc_oplogFrontiers(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Convert a version vector to frontiers
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * text.insert(0, "Hello");
     * const version = doc.version();
     * const frontiers = doc.vvToFrontiers(version);
     * ```
     * @param {VersionVector} vv
     * @returns {{ peer: PeerID, counter: number }[]}
     */
    vvToFrontiers(vv) {
        _assertClass(vv, VersionVector);
        const ret = wasm.lorodoc_vvToFrontiers(this.__wbg_ptr, vv.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * The doc only contains the history since this version
     *
     * This is empty if the doc is not shallow.
     *
     * The ops included by the shallow history start version vector are not in the doc.
     * @returns {VersionVector}
     */
    shallowSinceVV() {
        const ret = wasm.lorodoc_shallowSinceVV(this.__wbg_ptr);
        return VersionVector.__wrap(ret);
    }
    /**
     * Set the rich text format configuration of the document.
     *
     * You need to config it if you use rich text `mark` method.
     * Specifically, you need to config the `expand` property of each style.
     *
     * Expand is used to specify the behavior of expanding when new text is inserted at the
     * beginning or end of the style.
     *
     * You can specify the `expand` option to set the behavior when inserting text at the boundary of the range.
     *
     * - `after`(default): when inserting text right after the given range, the mark will be expanded to include the inserted text
     * - `before`: when inserting text right before the given range, the mark will be expanded to include the inserted text
     * - `none`: the mark will not be expanded to include the inserted text at the boundaries
     * - `both`: when inserting text either right before or right after the given range, the mark will be expanded to include the inserted text
     *
     * @example
     * ```ts
     * const doc = new LoroDoc();
     * doc.configTextStyle({
     *   bold: { expand: "after" },
     *   link: { expand: "before" }
     * });
     * const text = doc.getText("text");
     * text.insert(0, "Hello World!");
     * text.mark({ start: 0, end: 5 }, "bold", true);
     * expect(text.toDelta()).toStrictEqual([
     *   {
     *     insert: "Hello",
     *     attributes: {
     *       bold: true,
     *     },
     *   },
     *   {
     *     insert: " World!",
     *   },
     * ] as Delta<string>[]);
     * ```
     * @param {{[key: string]: { expand: 'before'|'after'|'none'|'both' }}} styles
     */
    configTextStyle(styles) {
        const ret = wasm.lorodoc_configTextStyle(this.__wbg_ptr, styles);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Get all ops of the change that contains the specific ID
     * @param {{ peer: PeerID, counter: number }} id
     * @returns {any[]}
     */
    getOpsInChange(id) {
        const ret = wasm.lorodoc_getOpsInChange(this.__wbg_ptr, id);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Get the shallow json format of the document state.
     *
     * Unlike `toJSON()` which recursively resolves all containers to their values,
     * `getShallowValue()` returns container IDs as strings for any nested containers.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getList("list");
     * const tree = doc.getTree("tree");
     * const map = doc.getMap("map");
     * const shallowValue = doc.getShallowValue();
     * console.log(shallowValue);
     * // {
     * //   list: 'cid:root-list:List',
     * //   tree: 'cid:root-tree:Tree',
     * //   map: 'cid:root-map:Map'
     * // }
     *
     * // It points to the same container as `list`
     * const listB = doc.getContainerById(shallowValue.list);
     * ```
     * @returns {Record<string, ContainerID>}
     */
    getShallowValue() {
        const ret = wasm.lorodoc_getShallowValue(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Checkout the `DocState` to the latest version of `OpLog`.
     *
     * > The document becomes detached during a `checkout` operation.
     * > Being `detached` implies that the `DocState` is not synchronized with the latest version of the `OpLog`.
     * > In a detached state, the document is not editable by default, and any `import` operations will be
     * > recorded in the `OpLog` without being applied to the `DocState`.
     *
     * This has the same effect as `attach`.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * const frontiers = doc.frontiers();
     * text.insert(0, "Hello World!");
     * doc.checkout(frontiers);
     * // you need call `checkoutToLatest()` or `attach()` before changing the doc.
     * doc.checkoutToLatest();
     * text.insert(0, "Hi");
     * ```
     */
    checkoutToLatest() {
        const ret = wasm.lorodoc_checkoutToLatest(this.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Compare the version of the OpLog with the specified frontiers.
     *
     * This method is useful to compare the version by only a small amount of data.
     *
     * This method returns an integer indicating the relationship between the version of the OpLog (referred to as 'self')
     * and the provided 'frontiers' parameter:
     *
     * - -1: The version of 'self' is either less than 'frontiers' or is non-comparable (parallel) to 'frontiers',
     *        indicating that it is not definitively less than 'frontiers'.
     * - 0: The version of 'self' is equal to 'frontiers'.
     * - 1: The version of 'self' is greater than 'frontiers'.
     *
     * # Internal
     *
     * Frontiers cannot be compared without the history of the OpLog.
     * @param {({ peer: PeerID, counter: number })[]} frontiers
     * @returns {number}
     */
    cmpWithFrontiers(frontiers) {
        const ptr0 = passArrayJsValueToWasm0(frontiers, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.lorodoc_cmpWithFrontiers(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0];
    }
    /**
     * @param {{ peer: PeerID, counter: number, length: number }} idSpan
     * @returns {any}
     */
    exportJsonInIdSpan(idSpan) {
        const ret = wasm.lorodoc_exportJsonInIdSpan(this.__wbg_ptr, idSpan);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Subscribe to changes that may affect a JSONPath query.
     *
     * The callback receives no query result; it is a lightweight notifier and may
     * fire false positives so callers can debounce/throttle before running JSONPath
     * themselves.
     * @param {string} jsonpath
     * @param {Function} f
     * @returns {any}
     */
    subscribeJsonpath(jsonpath, f) {
        const ptr0 = passStringToWasm0(jsonpath, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.lorodoc_subscribeJsonpath(this.__wbg_ptr, ptr0, len0, f);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Delete all content from a root container and hide it from the document.
     *
     * When a root container is empty and hidden:
     * - It won't show up in `get_deep_value()` results
     * - It won't be included in document snapshots
     *
     * Only works on root containers (containers without parents).
     * @param {ContainerID} cid
     */
    deleteRootContainer(cid) {
        const ret = wasm.lorodoc_deleteRootContainer(this.__wbg_ptr, cid);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Export updates in the given range in JSON format.
     * @param {any} start_vv
     * @param {any} end_vv
     * @param {boolean | null} [with_peer_compression]
     * @returns {JsonSchema}
     */
    exportJsonUpdates(start_vv, end_vv, with_peer_compression) {
        const ret = wasm.lorodoc_exportJsonUpdates(this.__wbg_ptr, start_vv, end_vv, isLikeNone(with_peer_compression) ? 0xFFFFFF : with_peer_compression ? 1 : 0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the container corresponding to the container id.
     *
     * If the container does not exist, it returns `undefined`.
     *
     * A mergeable container (created via `ensureMergeableMap` and friends) is resolvable
     * right after it has been ensured — even before any op is written into it — for as
     * long as the parent map's child ref is alive. A mergeable container id that was
     * never ensured on this doc resolves to `undefined`.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * let text = doc.getText("text");
     * const textId = text.id;
     * text = doc.getContainerById(textId);
     * ```
     * @param {ContainerID} container_id
     * @returns {any}
     */
    getContainerById(container_id) {
        const ret = wasm.lorodoc_getContainerById(this.__wbg_ptr, container_id);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the number of operations in the pending transaction.
     *
     * The pending transaction is the one that is not committed yet. It will be committed
     * automatically after calling `doc.commit()`, `doc.export(mode)` or `doc.checkout(version)`.
     * @returns {number}
     */
    getPendingTxnLength() {
        const ret = wasm.lorodoc_getPendingTxnLength(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Import updates from the JSON format.
     *
     * only supports backward compatibility but not forward compatibility.
     * @param {string | JsonSchema} json
     * @returns {ImportStatus}
     */
    importJsonUpdates(json) {
        const ret = wasm.lorodoc_importJsonUpdates(this.__wbg_ptr, json);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Import a batch of updates and snapshots.
     *
     * It's more efficient than importing updates one by one.
     *
     * @deprecated Use `importBatch` instead.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * text.insert(0, "Hello");
     * const updates = doc.export({ mode: "update" });
     * const snapshot = doc.export({ mode: "snapshot" });
     * const doc2 = new LoroDoc();
     * doc2.importBatch([snapshot, updates]);
     * ```
     * @param {Uint8Array[]} data
     * @returns {ImportStatus}
     */
    importUpdateBatch(data) {
        const ret = wasm.lorodoc_importUpdateBatch(this.__wbg_ptr, data);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Enables editing in detached mode, which is disabled by default.
     *
     * The doc enter detached mode after calling `detach` or checking out a non-latest version.
     *
     * # Important Notes:
     *
     * - This mode uses a different PeerID for each checkout.
     * - Ensure no concurrent operations share the same PeerID if set manually.
     * - Importing does not affect the document's state or version; changes are
     *   recorded in the [OpLog] only. Call `checkout` to apply changes.
     * @param {boolean} enable
     */
    setDetachedEditing(enable) {
        wasm.lorodoc_setDetachedEditing(this.__wbg_ptr, enable);
    }
    /**
     * Set whether to record the timestamp of each change. Default is `false`.
     *
     * If enabled, the Unix timestamp (in seconds) will be recorded for each change automatically.
     *
     * You can also set each timestamp manually when you commit a change.
     * The timestamp manually set will override the automatic one.
     *
     * NOTE: Timestamps are forced to be in ascending order in the OpLog's history.
     * If you commit a new change with a timestamp that is less than the existing one,
     * the largest existing timestamp will be used instead.
     * @param {boolean} auto_record
     */
    setRecordTimestamp(auto_record) {
        wasm.lorodoc_setRecordTimestamp(this.__wbg_ptr, auto_record);
    }
    /**
     * Subscribe to the pre-commit event.
     *
     * The callback will be called when the changes are committed but not yet applied to the OpLog.
     * You can modify the commit message and timestamp in the callback by `ChangeModifier`.
     * @param {Function} f
     * @returns {any}
     */
    subscribePreCommit(f) {
        const ret = wasm.lorodoc_subscribePreCommit(this.__wbg_ptr, f);
        return ret;
    }
    /**
     * Find the op id spans that between the `from` version and the `to` version.
     *
     * You can combine it with `exportJsonInIdSpan` to get the changes between two versions.
     *
     * You can use it to travel all the changes from `from` to `to`. `from` and `to` are frontiers,
     * and they can be concurrent to each other. You can use it to find all the changes related to an event:
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const docA = new LoroDoc();
     * docA.setPeerId("1");
     * const docB = new LoroDoc();
     *
     * docA.getText("text").update("Hello");
     * docA.commit();
     * const snapshot = docA.export({ mode: "snapshot" });
     * let done = false;
     * docB.subscribe(e => {
     *   const spans = docB.findIdSpansBetween(e.from, e.to);
     *   const changes = docB.exportJsonInIdSpan(spans.forward[0]);
     *   console.log(changes);
     *   // [{
     *   //   id: "0@1",
     *   //   timestamp: expect.any(Number),
     *   //   deps: [],
     *   //   lamport: 0,
     *   //   msg: undefined,
     *   //   ops: [{
     *   //     container: "cid:root-text:Text",
     *   //     counter: 0,
     *   //     content: {
     *   //       type: "insert",
     *   //       pos: 0,
     *   //       text: "Hello"
     *   //     }
     *   //   }]
     *   // }]
     * });
     * docB.import(snapshot);
     * ```
     * @param {({ peer: PeerID, counter: number })[]} from
     * @param {({ peer: PeerID, counter: number })[]} to
     * @returns {VersionVectorDiff}
     */
    findIdSpansBetween(from, to) {
        const ptr0 = passArrayJsValueToWasm0(from, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArrayJsValueToWasm0(to, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.lorodoc_findIdSpansBetween(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the change of with specific peer_id and lamport <= given lamport
     * @param {string} peer_id
     * @param {number} lamport
     * @returns {Change | undefined}
     */
    getChangeAtLamport(peer_id, lamport) {
        const ptr0 = passStringToWasm0(peer_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.lorodoc_getChangeAtLamport(this.__wbg_ptr, ptr0, len0, lamport);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the path from the root to the container
     * @param {ContainerID} id
     * @returns {(string|number)[] | undefined}
     */
    getPathToContainer(id) {
        const ret = wasm.lorodoc_getPathToContainer(this.__wbg_ptr, id);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Gets container IDs modified in the given ID range.
     *
     * **NOTE:** This method will implicitly commit.
     *
     * This method identifies which containers were affected by changes in a given range of operations.
     * It can be used together with `doc.travelChangeAncestors()` to analyze the history of changes
     * and determine which containers were modified by each change.
     *
     * @param id - The starting ID of the change range
     * @param len - The length of the change range to check
     * @returns An array of container IDs that were modified in the given range
     * @param {{ peer: PeerID, counter: number }} id
     * @param {number} len
     * @returns {ContainerID[]}
     */
    getChangedContainersIn(id, len) {
        const ret = wasm.lorodoc_getChangedContainersIn(this.__wbg_ptr, id, len);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Get deep value of the document with container id
     * @returns {any}
     */
    getDeepValueWithID() {
        const ret = wasm.lorodoc_getDeepValueWithID(this.__wbg_ptr);
        return ret;
    }
    /**
     * Set the origin of the next commit
     * @param {string} origin
     */
    setNextCommitOrigin(origin) {
        const ptr0 = passStringToWasm0(origin, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.lorodoc_setNextCommitOrigin(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * Get the pending operations from the current transaction in JSON format
     *
     * This method returns a JSON representation of operations that have been applied
     * but not yet committed in the current transaction.
     *
     * It will use the same data format as `doc.exportJsonUpdates()`
     *
     * @example
     * ```ts
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * text.insert(0, "Hello");
     * // Get pending ops before commit
     * const pendingOps = doc.getPendingOpsFromCurrentTxnAsJson();
     * doc.commit();
     * const emptyOps = doc.getPendingOpsFromCurrentTxnAsJson(); // this is undefined
     * ```
     * @returns {JsonSchema | undefined}
     */
    getUncommittedOpsAsJson() {
        const ret = wasm.lorodoc_getUncommittedOpsAsJson(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Set the commit message of the next commit
     * @param {string} msg
     */
    setNextCommitMessage(msg) {
        const ptr0 = passStringToWasm0(msg, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.lorodoc_setNextCommitMessage(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * Set the options of the next commit
     * @param {{ origin?: string, timestamp?: number, message?: string }} options
     */
    setNextCommitOptions(options) {
        const ret = wasm.lorodoc_setNextCommitOptions(this.__wbg_ptr, options);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * The doc only contains the history since this version
     *
     * This is empty if the doc is not shallow.
     *
     * The ops included by the shallow history start frontiers are not in the doc.
     * @returns {{ peer: PeerID, counter: number }[]}
     */
    shallowSinceFrontiers() {
        const ret = wasm.lorodoc_shallowSinceFrontiers(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Subscribe the updates from local edits
     * @param {Function} f
     * @returns {any}
     */
    subscribeLocalUpdates(f) {
        const ret = wasm.lorodoc_subscribeLocalUpdates(this.__wbg_ptr, f);
        return ret;
    }
    /**
     * Visit all the ancestors of the changes in causal order.
     *
     * @param ids - the changes to visit
     * @param f - the callback function, return `true` to continue visiting, return `false` to stop
     * @param {({ peer: PeerID, counter: number })[]} ids
     * @param {(change: Change) => boolean} f
     */
    travelChangeAncestors(ids, f) {
        const ptr0 = passArrayJsValueToWasm0(ids, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.lorodoc_travelChangeAncestors(this.__wbg_ptr, ptr0, len0, f);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Clear the options of the next commit
     */
    clearNextCommitOptions() {
        wasm.lorodoc_clearNextCommitOptions(this.__wbg_ptr);
    }
    /**
     * Configures the default text style for the document.
     *
     * This method sets the default text style configuration for the document when using LoroText.
     * If `None` is provided, the default style is reset.
     * @param {{ expand: 'before'|'after'|'none'|'both' } | undefined} style
     */
    configDefaultTextStyle(style) {
        const ret = wasm.lorodoc_configDefaultTextStyle(this.__wbg_ptr, style);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * If two continuous local changes are within (<=) the interval(**in seconds**), they will be merged into one change.
     *
     * The default value is 1_000 seconds.
     *
     * By default, we record timestamps in seconds for each change. So if the merge interval is 1, and changes A and B
     * have timestamps of 3 and 4 respectively, then they will be merged into one change
     * @param {number} interval
     */
    setChangeMergeInterval(interval) {
        wasm.lorodoc_setChangeMergeInterval(this.__wbg_ptr, interval);
    }
    /**
     * Set the timestamp of the next commit
     * @param {number} timestamp
     */
    setNextCommitTimestamp(timestamp) {
        wasm.lorodoc_setNextCommitTimestamp(this.__wbg_ptr, timestamp);
    }
    /**
     * Set whether to hide empty root containers.
     *
     * @example
     * ```ts
     * const doc = new LoroDoc();
     * const map = doc.getMap("map");
     * console.log(doc.toJSON()); // { map: {} }
     * doc.setHideEmptyRootContainers(true);
     * console.log(doc.toJSON()); // {}
     * ```
     * @param {boolean} hide
     */
    setHideEmptyRootContainers(hide) {
        const ret = wasm.lorodoc_setHideEmptyRootContainers(this.__wbg_ptr, hide);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Whether the editing is enabled in detached mode.
     *
     * The doc enter detached mode after calling `detach` or checking out a non-latest version.
     *
     * # Important Notes:
     *
     * - This mode uses a different PeerID for each checkout.
     * - Ensure no concurrent operations share the same PeerID if set manually.
     * - Importing does not affect the document's state or version; changes are
     *   recorded in the [OpLog] only. Call `checkout` to apply changes.
     * @returns {boolean}
     */
    isDetachedEditingEnabled() {
        const ret = wasm.lorodoc_isDetachedEditingEnabled(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @param {Function} f
     * @returns {any}
     */
    subscribeFirstCommitFromPeer(f) {
        const ret = wasm.lorodoc_subscribeFirstCommitFromPeer(this.__wbg_ptr, f);
        return ret;
    }
    /**
     * Create a new loro document.
     *
     * New document will have a random peer id.
     */
    constructor() {
        const ret = wasm.lorodoc_new();
        this.__wbg_ptr = ret >>> 0;
        LoroDocFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Calculate the differences between two frontiers
     *
     * The entries in the returned object are sorted by causal order: the creation of a child container will be
     * presented before its use.
     * @param {({ peer: PeerID, counter: number })[]} from
     * @param {({ peer: PeerID, counter: number })[]} to
     * @param {boolean | null} [for_json]
     * @returns {[ContainerID, Diff|JsonDiff][]}
     */
    diff(from, to, for_json) {
        const ptr0 = passArrayJsValueToWasm0(from, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArrayJsValueToWasm0(to, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.lorodoc_diff(this.__wbg_ptr, ptr0, len0, ptr1, len1, isLikeNone(for_json) ? 0xFFFFFF : for_json ? 1 : 0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Duplicate the document with a different PeerID
     *
     * The time complexity and space complexity of this operation are both O(n),
     *
     * When called in detached mode, it will fork at the current state frontiers.
     * It will have the same effect as `forkAt(&self.frontiers())`.
     * @returns {LoroDoc}
     */
    fork() {
        const ret = wasm.lorodoc_fork(this.__wbg_ptr);
        return LoroDoc.__wrap(ret);
    }
    /**
     * Attach the document state to the latest known version.
     *
     * > The document becomes detached during a `checkout` operation.
     * > Being `detached` implies that the `DocState` is not synchronized with the latest version of the `OpLog`.
     * > In a detached state, the document is not editable, and any `import` operations will be
     * > recorded in the `OpLog` without being applied to the `DocState`.
     *
     * This method has the same effect as invoking `checkoutToLatest`.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * const frontiers = doc.frontiers();
     * text.insert(0, "Hello World!");
     * doc.checkout(frontiers);
     * // you need call `attach()` or `checkoutToLatest()` before changing the doc.
     * doc.attach();
     * text.insert(0, "Hi");
     * ```
     */
    attach() {
        wasm.lorodoc_attach(this.__wbg_ptr);
    }
    /**
     * Commit the cumulative auto-committed transaction.
     *
     * You can specify the `origin`, `timestamp`, and `message` of the commit.
     *
     * - The `origin` is used to mark the event
     * - The `message` works like a git commit message, which will be recorded and synced to peers
     * - The `timestamp` is the number of seconds that have elapsed since 00:00:00 UTC on January 1, 1970.
     *   It defaults to `Date.now() / 1000` when timestamp recording is enabled
     *
     * The events will be emitted after a transaction is committed. A transaction is committed when:
     *
     * - `doc.commit()` is called.
     * - `doc.export(mode)` is called.
     * - `doc.import(data)` is called.
     * - `doc.checkout(version)` is called.
     *
     * NOTE: Timestamps are forced to be in ascending order.
     * If you commit a new change with a timestamp that is less than the existing one,
     * the largest existing timestamp will be used instead.
     *
     * NOTE: The `origin` will not be persisted, but the `message` will.
     *
     * Behavior on empty commits:
     * - This method is an explicit commit. If the pending transaction is empty, any provided
     *   options (message/timestamp/origin) are swallowed and will not carry over to the next commit.
     * - Implicit commits triggered by `export`/`checkout` act as processing barriers. If the
     *   transaction is empty in those cases, `message`/`timestamp`/`origin` are preserved for the
     *   next commit.
     * @param {{ origin?: string, timestamp?: number, message?: string } | null} [options]
     */
    commit(options) {
        const ret = wasm.lorodoc_commit(this.__wbg_ptr, isLikeNone(options) ? 0 : addToExternrefTable0(options));
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Detach the document state from the latest known version.
     *
     * After detaching, all import operations will be recorded in the `OpLog` without being applied to the `DocState`.
     * When `detached`, the document is not editable.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * doc.detach();
     * console.log(doc.isDetached());  // true
     * ```
     */
    detach() {
        wasm.lorodoc_detach(this.__wbg_ptr);
    }
    /**
     * Export the document based on the specified ExportMode.
     *
     * @param mode - The export mode to use. Can be one of:
     *   - `{ mode: "snapshot" }`: Export a full snapshot of the document.
     *   - `{ mode: "update", from?: VersionVector }`: Export updates from the given version vector.
     *     If `from` is not provided, it will export the whole history of the document.
     *   - `{ mode: "updates-in-range", spans: { id: ID, len: number }[] }`: Export updates within the specified ID spans.
     *   - `{ mode: "shallow-snapshot", frontiers: Frontiers }`: Export a garbage-collected snapshot up to the given frontiers.
     *
     * @returns A byte array containing the exported data.
     *
     * @example
     * ```ts
     * import { LoroDoc, LoroText } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * doc.setPeerId("1");
     * doc.getText("text").update("Hello World");
     *
     * // Export a full snapshot
     * const snapshotBytes = doc.export({ mode: "snapshot" });
     *
     * // Export updates from a specific version
     * const vv = doc.oplogVersion();
     * doc.getText("text").update("Hello Loro");
     * const updateBytes = doc.export({ mode: "update", from: vv });
     *
     * // Export a shallow snapshot that only includes the history since the frontiers
     * const shallowBytes = doc.export({ mode: "shallow-snapshot", frontiers: doc.oplogFrontiers() });
     *
     * // Export updates within specific ID spans
     * const spanBytes = doc.export({
     *   mode: "updates-in-range",
     *   spans: [{ id: { peer: "1", counter: 0 }, len: 10 }]
     * });
     * ```
     * @param {ExportMode} mode
     * @returns {Uint8Array}
     */
    export(mode) {
        const ret = wasm.lorodoc_export(this.__wbg_ptr, mode);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * Import snapshot or updates into current doc.
     *
     * Note:
     * - Updates within the current version will be ignored
     * - Updates with missing dependencies will be pending until the dependencies are received
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * text.insert(0, "Hello");
     * // get all updates of the doc
     * const updates = doc.export({ mode: "update" });
     * const snapshot = doc.export({ mode: "snapshot" });
     * const doc2 = new LoroDoc();
     * // import snapshot
     * doc2.import(snapshot);
     * // or import updates
     * doc2.import(updates);
     * ```
     * @param {Uint8Array} update_or_snapshot
     * @returns {ImportStatus}
     */
    import(update_or_snapshot) {
        const ptr0 = passArray8ToWasm0(update_or_snapshot, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.lorodoc_import(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Creates a new LoroDoc at a specified version (Frontiers)
     *
     * The created doc will only contain the history before the specified frontiers.
     * @param {({ peer: PeerID, counter: number })[]} frontiers
     * @returns {LoroDoc}
     */
    forkAt(frontiers) {
        const ptr0 = passArrayJsValueToWasm0(frontiers, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.lorodoc_forkAt(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return LoroDoc.__wrap(ret[0]);
    }
    /**
     * Get a LoroMap by container id
     *
     * The object returned is a new js object each time because it need to cross
     * the WASM boundary.
     *
     * If the container does not exist, an error will be thrown.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const map = doc.getMap("map");
     * ```
     * @param {ContainerID | string} cid
     * @returns {LoroMap}
     */
    getMap(cid) {
        const ret = wasm.lorodoc_getMap(this.__wbg_ptr, cid);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return LoroMap.__wrap(ret[0]);
    }
    /**
     * Get the number of ops in the oplog.
     * @returns {number}
     */
    opCount() {
        const ret = wasm.lorodoc_opCount(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Peer ID of the current writer.
     * @returns {bigint}
     */
    get peerId() {
        const ret = wasm.lorodoc_peerId(this.__wbg_ptr);
        return BigInt.asUintN(64, ret);
    }
    /**
     * Get the json format of the entire document state.
     *
     * Unlike `getShallowValue()` which returns container IDs as strings,
     * `toJSON()` recursively resolves all containers to their actual values.
     *
     * @example
     * ```ts
     * import { LoroDoc, LoroText, LoroMap } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getList("list");
     * list.insert(0, "Hello");
     * const text = list.insertContainer(0, new LoroText());
     * text.insert(0, "Hello");
     * const map = list.insertContainer(1, new LoroMap());
     * map.set("foo", "bar");
     * console.log(doc.toJSON());
     * // {"list": ["Hello", {"foo": "bar"}]}
     * ```
     * @returns {any}
     */
    toJSON() {
        const ret = wasm.lorodoc_toJSON(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the version vector of the current document state.
     *
     * If you checkout to a specific version, the version vector will change.
     * @returns {VersionVector}
     */
    version() {
        const ret = wasm.lorodoc_version(this.__wbg_ptr);
        return VersionVector.__wrap(ret);
    }
    /**
     * Checkout the `DocState` to a specific version.
     *
     * > The document becomes detached during a `checkout` operation.
     * > Being `detached` implies that the `DocState` is not synchronized with the latest version of the `OpLog`.
     * > In a detached state, the document is not editable, and any `import` operations will be
     * > recorded in the `OpLog` without being applied to the `DocState`.
     *
     * You should call `attach` to attach the `DocState` to the latest version of `OpLog`.
     *
     * @param frontiers - the specific frontiers
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * const frontiers = doc.frontiers();
     * text.insert(0, "Hello World!");
     * doc.checkout(frontiers);
     * console.log(doc.toJSON()); // {"text": ""}
     * ```
     * @param {({ peer: PeerID, counter: number })[]} frontiers
     */
    checkout(frontiers) {
        const ptr0 = passArrayJsValueToWasm0(frontiers, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.lorodoc_checkout(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Get a LoroList by container id
     *
     * The object returned is a new js object each time because it need to cross
     * the WASM boundary.
     *
     * If the container does not exist, an error will be thrown.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getList("list");
     * ```
     * @param {ContainerID | string} cid
     * @returns {LoroList}
     */
    getList(cid) {
        const ret = wasm.lorodoc_getList(this.__wbg_ptr, cid);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return LoroList.__wrap(ret[0]);
    }
    /**
     * Get a LoroText by container id.
     *
     * The object returned is a new js object each time because it need to cross
     * the WASM boundary.
     *
     * If the container does not exist, an error will be thrown.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * ```
     * @param {ContainerID | string} cid
     * @returns {LoroText}
     */
    getText(cid) {
        const ret = wasm.lorodoc_getText(this.__wbg_ptr, cid);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return LoroText.__wrap(ret[0]);
    }
    /**
     * Get a LoroTree by container id
     *
     * The object returned is a new js object each time because it need to cross
     * the WASM boundary.
     *
     * If the container does not exist, an error will be thrown.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const tree = doc.getTree("tree");
     * ```
     * @param {ContainerID | string} cid
     * @returns {LoroTree}
     */
    getTree(cid) {
        const ret = wasm.lorodoc_getTree(this.__wbg_ptr, cid);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return LoroTree.__wrap(ret[0]);
    }
    /**
     * Get the [frontiers](https://loro.dev/docs/advanced/version_deep_dive) of the current document state.
     *
     * If you checkout to a specific version, this value will change.
     * @returns {{ peer: PeerID, counter: number }[]}
     */
    frontiers() {
        const ret = wasm.lorodoc_frontiers(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Evaluate JSONPath against a LoroDoc
     * @param {string} jsonpath
     * @returns {Array<any>}
     */
    JSONPath(jsonpath) {
        const ptr0 = passStringToWasm0(jsonpath, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.lorodoc_JSONPath(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Revert the document to the given frontiers.
     *
     * The doc will not become detached when using this method. Instead, it will generate a series
     * of operations to revert the document to the given version.
     *
     * @example
     * ```ts
     * const doc = new LoroDoc();
     * doc.setPeerId("1");
     * const text = doc.getText("text");
     * text.insert(0, "Hello");
     * doc.commit();
     * doc.revertTo([{ peer: "1", counter: 1 }]);
     * expect(doc.getText("text").toString()).toBe("He");
     * ```
     * @param {({ peer: PeerID, counter: number })[]} frontiers
     */
    revertTo(frontiers) {
        const ptr0 = passArrayJsValueToWasm0(frontiers, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.lorodoc_revertTo(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Subscribe to the changes of the loro document. The function will be called when the
     * transaction is committed and after importing updates/snapshot from remote.
     *
     * Returns a subscription callback, which can be used to unsubscribe.
     *
     * The events will be emitted after a transaction is committed. A transaction is committed when:
     *
     * - `doc.commit()` is called.
     * - `doc.export(mode)` is called.
     * - `doc.import(data)` is called.
     * - `doc.checkout(version)` is called.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * const sub = doc.subscribe((event)=>{
     *     console.log(event);
     * });
     * text.insert(0, "Hello");
     * // the events will be emitted when `commit()` is called.
     * doc.commit();
     * // unsubscribe
     * sub();
     * ```
     * @param {Function} f
     * @returns {any}
     */
    subscribe(f) {
        const ret = wasm.lorodoc_subscribe(this.__wbg_ptr, f);
        return ret;
    }
    /**
     * Convert visible roots to independent container trees without committing.
     * The text format applies recursively, including Tree metadata. Unknown or
     * hidden roots are omitted; roots: [] returns an empty object. Reads never
     * create roots. Binary values are owned Uint8Arrays. Not a CRDT export.
     * @param {DocumentContainerTreeOptions | null} [opts]
     * @returns {Record<string, ContainerNode>}
     */
    toContainerTree(opts) {
        const ret = wasm.lorodoc_toContainerTree(this.__wbg_ptr, isLikeNone(opts) ? 0 : addToExternrefTable0(opts));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
module.exports.LoroDoc = LoroDoc;

const LoroListFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_lorolist_free(ptr >>> 0, 1));
/**
 * The handler of a list container.
 *
 * Learn more at https://loro.dev/docs/tutorial/list
 */
class LoroList {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(LoroList.prototype);
        obj.__wbg_ptr = ptr;
        LoroListFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        LoroListFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_lorolist_free(ptr, 0);
    }
    /**
     * Whether the container is attached to a document.
     *
     * If it's detached, the operations on the container will not be persisted.
     * @returns {boolean}
     */
    isAttached() {
        const ret = wasm.lorolist_isAttached(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Get the attached container associated with this.
     *
     * Returns an attached `Container` that equals to this or created by this, otherwise `undefined`.
     * @returns {LoroList | undefined}
     */
    getAttached() {
        const ret = wasm.lorolist_getAttached(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {Container} child
     * @returns {Container}
     */
    pushContainer(child) {
        const ret = wasm.lorolist_pushContainer(this.__wbg_ptr, child);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the deep value of the elements in the range `[start, end)`.
     *
     * Each child container in the range is recursively resolved to its deep
     * value. Negative bounds are clamped to 0 and out-of-range bounds are
     * clamped to the list length; an empty or inverted range returns `[]`.
     *
     * @example
     * ```ts
     * import { LoroDoc, LoroText } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getList("list");
     * list.insert(0, 100);
     * const text = list.insertContainer(1, new LoroText());
     * text.insert(0, "Hello");
     * console.log(list.getRangeValue(0, 2));  // [100, "Hello"]
     * ```
     * @param {number} start
     * @param {number} end
     * @returns {any}
     */
    getRangeValue(start, end) {
        const ret = wasm.lorolist_getRangeValue(this.__wbg_ptr, start, end);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Insert a container at the index.
     *
     * @example
     * ```ts
     * import { LoroDoc, LoroText } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getList("list");
     * list.insert(0, 100);
     * const text = list.insertContainer(1, new LoroText());
     * text.insert(0, "Hello");
     * console.log(list.toJSON());  // [100, "Hello"];
     * ```
     * @param {number} index
     * @param {Container} child
     * @returns {Container}
     */
    insertContainer(index, child) {
        const ret = wasm.lorolist_insertContainer(this.__wbg_ptr, index, child);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the shallow value of the list.
     *
     * Unlike `toJSON()` which recursively resolves all containers to their values,
     * `getShallowValue()` returns container IDs as strings for any nested containers.
     *
     * ```js
     * const doc = new LoroDoc();
     * doc.setPeerId("1");
     * const list = doc.getList("list");
     * list.insert(0, 1);
     * list.insert(1, "two");
     * const subList = list.insertContainer(2, new LoroList());
     * subList.insert(0, "sub");
     * list.getShallowValue(); // [1, "two", "cid:2@1:List"]
     * list.toJSON(); // [1, "two", ["sub"]]
     * ```
     * @returns {Value[]}
     */
    getShallowValue() {
        const ret = wasm.lorolist_getShallowValue(this.__wbg_ptr);
        return ret;
    }
    /**
     * Get the deep value of the list with its container id.
     *
     * The result is a `{ cid, value }` object, where `cid` is the container id
     * string (the same as `list.id`) and `value` is the deep value of the
     * list. Child containers inside `value` are recursively replaced by their
     * own `{ cid, value }` nodes. This is the same node shape that
     * `LoroDoc.getDeepValueWithID()` emits for every container.
     *
     * @example
     * ```ts
     * import { LoroDoc, LoroText } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getList("list");
     * list.insert(0, 100);
     * const text = list.insertContainer(1, new LoroText());
     * text.insert(0, "Hello");
     * console.log(list.getDeepValueWithID());
     * // { cid: "cid:root-list:List",
     * //   value: [100, { cid: "cid:0@1:Text", value: "Hello" }] }
     * ```
     * @returns {any}
     */
    getDeepValueWithID() {
        const ret = wasm.lorolist_getDeepValueWithID(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the deep value of the elements in the range `[start, end)`, with
     * container ids.
     *
     * Each child container in the range is recursively replaced by its own
     * `{ cid, value }` node. Negative bounds are clamped to 0 and
     * out-of-range bounds are clamped to the list length; an empty or
     * inverted range returns `[]`.
     *
     * @example
     * ```ts
     * import { LoroDoc, LoroText } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getList("list");
     * list.insert(0, 100);
     * const text = list.insertContainer(1, new LoroText());
     * text.insert(0, "Hello");
     * console.log(list.getRangeDeepValueWithID(0, 2));
     * // [100, { cid: "cid:0@1:Text", value: "Hello" }]
     * ```
     * @param {number} start
     * @param {number} end
     * @returns {any}
     */
    getRangeDeepValueWithID(start, end) {
        const ret = wasm.lorolist_getRangeDeepValueWithID(this.__wbg_ptr, start, end);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the id of this container.
     * @returns {ContainerID}
     */
    get id() {
        const ret = wasm.lorolist_id(this.__wbg_ptr);
        return ret;
    }
    /**
     * Get the value at the index. If the value is a container, the corresponding handler will be returned.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getList("list");
     * list.insert(0, 100);
     * console.log(list.get(0));  // 100
     * console.log(list.get(1));  // undefined
     * ```
     * @param {number} index
     * @returns {Value | Container | undefined}
     */
    get(index) {
        const ret = wasm.lorolist_get(this.__wbg_ptr, index);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Create a new detached LoroList (not attached to any LoroDoc).
     *
     * The edits on a detached container will not be persisted.
     * To attach the container to the document, please insert it into an attached container.
     */
    constructor() {
        const ret = wasm.lorolist_new();
        this.__wbg_ptr = ret >>> 0;
        LoroListFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Pop a value from the end of the list.
     * @returns {Value | undefined}
     */
    pop() {
        const ret = wasm.lorolist_pop(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * "List"
     * @returns {'List'}
     */
    kind() {
        const ret = wasm.lorolist_kind(this.__wbg_ptr);
        return ret;
    }
    /**
     * Push a value to the end of the list.
     * @param {Value} value
     */
    push(value) {
        const ret = wasm.lorolist_push(this.__wbg_ptr, value);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Delete all elements in the list.
     */
    clear() {
        const ret = wasm.lorolist_clear(this.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Delete elements from index to index + len.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getList("list");
     * list.insert(0, 100);
     * list.delete(0, 1);
     * console.log(list.value);  // []
     * ```
     * @param {number} index
     * @param {number} len
     */
    delete(index, len) {
        const ret = wasm.lorolist_delete(this.__wbg_ptr, index, len);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Insert a value at index.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getList("list");
     * list.insert(0, 100);
     * list.insert(1, "foo");
     * list.insert(2, true);
     * console.log(list.value);  // [100, "foo", true];
     * ```
     * @param {number} index
     * @param {Value} value
     */
    insert(index, value) {
        const ret = wasm.lorolist_insert(this.__wbg_ptr, index, value);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Get the length of list.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getList("list");
     * list.insert(0, 100);
     * list.insert(1, "foo");
     * list.insert(2, true);
     * console.log(list.length);  // 3
     * ```
     * @returns {number}
     */
    get length() {
        const ret = wasm.lorolist_length(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Get the parent container.
     *
     * - The parent container of the root tree is `undefined`.
     * - The object returned is a new js object each time because it need to cross
     *   the WASM boundary.
     * @returns {Container | undefined}
     */
    parent() {
        const ret = wasm.lorolist_parent(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {number} pos
     * @returns {{ peer: PeerID, counter: number } | undefined}
     */
    getIdAt(pos) {
        const ret = wasm.lorolist_getIdAt(this.__wbg_ptr, pos);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get elements of the list. If the type of a element is a container, it will be
     * resolved recursively.
     *
     * @example
     * ```ts
     * import { LoroDoc, LoroText } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getList("list");
     * list.insert(0, 100);
     * const text = list.insertContainer(1, new LoroText());
     * text.insert(0, "Hello");
     * console.log(list.toJSON());  // [100, "Hello"];
     * ```
     * @returns {any}
     */
    toJSON() {
        const ret = wasm.lorolist_toJSON(this.__wbg_ptr);
        return ret;
    }
    /**
     * Get elements of the list. If the value is a child container, the corresponding
     * `Container` will be returned.
     *
     * @example
     * ```ts
     * import { LoroDoc, LoroText } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getList("list");
     * list.insert(0, 100);
     * list.insert(1, "foo");
     * list.insert(2, true);
     * list.insertContainer(3, new LoroText());
     * console.log(list.value);  // [100, "foo", true, LoroText];
     * ```
     * @returns {(Value | Container)[]}
     */
    toArray() {
        const ret = wasm.lorolist_toArray(this.__wbg_ptr);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Get the cursor at the position.
     *
     * - The first argument is the position .
     * - The second argument is the side: `-1` for left, `0` for middle, `1` for right.
     * @param {number} pos
     * @param {Side} side
     * @returns {Cursor | undefined}
     */
    getCursor(pos, side) {
        const ret = wasm.lorolist_getCursor(this.__wbg_ptr, pos, side);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] === 0 ? undefined : Cursor.__wrap(ret[0]);
    }
    /**
     * Check if the container is deleted
     * @returns {boolean}
     */
    isDeleted() {
        const ret = wasm.lorolist_isDeleted(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Subscribe to the changes of the list.
     *
     * Returns a subscription callback, which can be used to unsubscribe.
     *
     * The events will be emitted after a transaction is committed. A transaction is committed when:
     *
     * - `doc.commit()` is called.
     * - `doc.export(mode)` is called.
     * - `doc.import(data)` is called.
     * - `doc.checkout(version)` is called.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getList("list");
     * list.subscribe((event)=>{
     *     console.log(event);
     * });
     * list.insert(0, 100);
     * doc.commit();
     * ```
     * @param {Function} f
     * @returns {any}
     */
    subscribe(f) {
        const ret = wasm.lorolist_subscribe(this.__wbg_ptr, f);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Convert this attached container and all descendants to an independent tree.
     * Text format applies recursively. Does not commit; throws for detached
     * containers, unsupported types, invalid options, or nesting above 256.
     * @param {ContainerTreeOptions | null} [opts]
     * @returns {ContainerNode}
     */
    toContainerTree(opts) {
        const ret = wasm.lorolist_toContainerTree(this.__wbg_ptr, isLikeNone(opts) ? 0 : addToExternrefTable0(opts));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Read [start,end), clamped to list length. Inverted bounds return no items.
     * Returns actual start, totalLength and items; this is not a complete container.
     * Only selected descendants are traversed; parent shallow list access is O(N).
     * @param {number} start
     * @param {number} end
     * @param {ContainerTreeOptions | null} [opts]
     * @returns {ContainerTreeSlice}
     */
    toContainerTreeSlice(start, end, opts) {
        const ret = wasm.lorolist_toContainerTreeSlice(this.__wbg_ptr, start, end, isLikeNone(opts) ? 0 : addToExternrefTable0(opts));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
module.exports.LoroList = LoroList;

const LoroMapFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_loromap_free(ptr >>> 0, 1));
/**
 * The handler of a map container.
 *
 * Learn more at https://loro.dev/docs/tutorial/map
 *
 * ## Mergeable child containers
 *
 * `ensureMergeable*` methods create deterministic child containers under a map
 * key. If two peers independently call the same method with the same parent
 * map, key, and container type, they get the same child container id and their
 * subsequent edits merge in that child.
 *
 * Loro activates a mergeable child by writing a specially constructed binary
 * marker value into the parent map slot. String values do not activate
 * mergeable children. If the key already holds a non-mergeable value,
 * `ensureMergeable*` returns an error and leaves the value unchanged.
 * Calling `ensureMergeable*` with a different container type at an existing
 * mergeable key is a deliberate kind change: the map slot activates the new
 * type, while the state of the other mergeable child remains preserved under
 * its deterministic id.
 *
 * Deleting the map key clears the ref and hides the mergeable child, but the
 * child's state is preserved. Calling the same `ensureMergeable*` method again
 * writes the ref back and resurfaces the preserved state.
 */
class LoroMap {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(LoroMap.prototype);
        obj.__wbg_ptr = ptr;
        LoroMapFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        LoroMapFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_loromap_free(ptr, 0);
    }
    /**
     * Whether the container is attached to a document.
     *
     * If it's detached, the operations on the container will not be persisted.
     * @returns {boolean}
     */
    isAttached() {
        const ret = wasm.lorolist_isAttached(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Get the attached container associated with this.
     *
     * Returns an attached `Container` that equals to this or created by this, otherwise `undefined`.
     * @returns {LoroMap | undefined}
     */
    getAttached() {
        const ret = wasm.loromap_getAttached(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the peer id of the last editor on the given entry
     * @param {string} key
     * @returns {PeerID | undefined}
     */
    getLastEditor(key) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.loromap_getLastEditor(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Set the key with a regular child container.
     *
     * The inserted child receives a regular op-created container id. Use this
     * for replacement semantics or when each creation should produce a distinct
     * child. Use `ensureMergeable*` when peers may lazily initialize the same
     * logical child under a map key.
     *
     * @example
     * ```ts
     * import { LoroDoc, LoroText, LoroList } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const map = doc.getMap("map");
     * map.set("foo", "bar");
     * const text = map.setContainer("text", new LoroText());
     * const list = map.setContainer("list", new LoroList());
     * ```
     * @param {string} key
     * @param {Container} child
     * @returns {Container}
     */
    setContainer(key, child) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.loromap_setContainer(this.__wbg_ptr, ptr0, len0, child);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the shallow value of the map.
     *
     * Unlike `toJSON()` which recursively resolves all containers to their values,
     * `getShallowValue()` returns container IDs as strings for any nested containers.
     *
     * @example
     * ```ts
     * import { LoroDoc, LoroText } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * doc.setPeerId("1");
     * const map = doc.getMap("map");
     * map.set("key", "value");
     * const subText = map.setContainer("text", new LoroText());
     * subText.insert(0, "Hello");
     *
     * // Get shallow value - nested containers are represented by their IDs
     * console.log(map.getShallowValue());
     * // Output: { key: "value", text: "cid:1@1:Text" }
     *
     * // Get full value with nested containers resolved by `toJSON()`
     * console.log(map.toJSON());
     * // Output: { key: "value", text: "Hello" }
     * ```
     * @returns {Record<string, Value>}
     */
    getShallowValue() {
        const ret = wasm.loromap_getShallowValue(this.__wbg_ptr);
        return ret;
    }
    /**
     * Ensure a mergeable Map exists under the given key and return it.
     *
     * If the map is detached, or if the key already holds a non-mergeable
     * value, this throws and leaves the value unchanged.
     *
     * Prefer to avoid very deep mergeable-map chains: mergeable cids encode
     * their flattened logical path, so cid size still grows with depth and
     * rides through every op/snapshot reference to it.
     * @param {string} key
     * @returns {LoroMap}
     */
    ensureMergeableMap(key) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.loromap_ensureMergeableMap(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return LoroMap.__wrap(ret[0]);
    }
    /**
     * Ensure a mergeable List exists under the given key and return it.
     *
     * If the map is detached, or if the key already holds a non-mergeable
     * value, this throws and leaves the value unchanged.
     * @param {string} key
     * @returns {LoroList}
     */
    ensureMergeableList(key) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.loromap_ensureMergeableList(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return LoroList.__wrap(ret[0]);
    }
    /**
     * Ensure a mergeable Text exists under the given key and return it.
     *
     * If the map is detached, or if the key already holds a non-mergeable
     * value, this throws and leaves the value unchanged.
     * @param {string} key
     * @returns {LoroText}
     */
    ensureMergeableText(key) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.loromap_ensureMergeableText(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return LoroText.__wrap(ret[0]);
    }
    /**
     * Ensure a mergeable Tree exists under the given key and return it.
     *
     * If the map is detached, or if the key already holds a non-mergeable
     * value, this throws and leaves the value unchanged.
     * @param {string} key
     * @returns {LoroTree}
     */
    ensureMergeableTree(key) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.loromap_ensureMergeableTree(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return LoroTree.__wrap(ret[0]);
    }
    /**
     * Get the deep value of the map with its container id.
     *
     * The result is a `{ cid, value }` object, where `cid` is the container id
     * string (the same as `map.id`) and `value` is the deep value of the map.
     * Child containers inside `value` are recursively replaced by their own
     * `{ cid, value }` nodes. This is the same node shape that
     * `LoroDoc.getDeepValueWithID()` emits for every container.
     *
     * @example
     * ```ts
     * import { LoroDoc, LoroText } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const map = doc.getMap("map");
     * map.set("foo", "bar");
     * const text = map.setContainer("text", new LoroText());
     * text.insert(0, "Hello");
     * console.log(map.getDeepValueWithID());
     * // { cid: "cid:root-map:Map",
     * //   value: { foo: "bar", text: { cid: "cid:0@1:Text", value: "Hello" } } }
     * ```
     * @returns {any}
     */
    getDeepValueWithID() {
        const ret = wasm.loromap_getDeepValueWithID(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get or create a regular child container at the given key.
     *
     * @deprecated Use `ensureMergeable*` for lazy map-key child creation. This
     * method creates regular op-id children, so concurrent first creation at
     * the same key can fork child state and leave one branch hidden by map
     * conflict resolution. Use `setContainer` for regular replacement/attach
     * semantics.
     *
     * If the key is empty or `null`, this creates a regular child container.
     * If the key already holds a child of the same type, it returns that child.
     * If the key holds a scalar or a child of another type, it throws.
     *
     * @example
     * ```ts
     * import { LoroDoc, LoroText } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const map = doc.getMap("map");
     * const text = map.getOrCreateContainer("text", new LoroText());
     * text.insert(0, "legacy regular child");
     * ```
     * @param {string} key
     * @param {Container} child
     * @returns {Container}
     */
    getOrCreateContainer(key, child) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.loromap_getOrCreateContainer(this.__wbg_ptr, ptr0, len0, child);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Ensure a mergeable Counter exists under the given key and return it.
     *
     * If the map is detached, or if the key already holds a non-mergeable
     * value, this throws and leaves the value unchanged.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const counter = doc.getMap("state").ensureMergeableCounter("revision");
     * counter.increment(1);
     * ```
     * @param {string} key
     * @returns {LoroCounter}
     */
    ensureMergeableCounter(key) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.loromap_ensureMergeableCounter(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return LoroCounter.__wrap(ret[0]);
    }
    /**
     * Ensure a mergeable MovableList exists under the given key and return it.
     *
     * If the map is detached, or if the key already holds a non-mergeable
     * value, this throws and leaves the value unchanged.
     * @param {string} key
     * @returns {LoroMovableList}
     */
    ensureMergeableMovableList(key) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.loromap_ensureMergeableMovableList(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return LoroMovableList.__wrap(ret[0]);
    }
    /**
     * The container id of this handler.
     * @returns {ContainerID}
     */
    get id() {
        const ret = wasm.loromap_id(this.__wbg_ptr);
        return ret;
    }
    /**
     * Get the value of the key. If the value is a child container, the corresponding
     * `Container` will be returned.
     *
     * The object/value returned is a new js object/value each time because it need to cross
     * the WASM boundary.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const map = doc.getMap("map");
     * map.set("foo", "bar");
     * const bar = map.get("foo");
     * ```
     * @param {string} key
     * @returns {Value | Container | undefined}
     */
    get(key) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.loromap_get(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Create a new detached LoroMap (not attached to any LoroDoc).
     *
     * The edits on a detached container will not be persisted.
     * To attach the container to the document, please insert it into an attached container.
     */
    constructor() {
        const ret = wasm.loromap_new();
        this.__wbg_ptr = ret >>> 0;
        LoroMapFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Get the keys of the map.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const map = doc.getMap("map");
     * map.set("foo", "bar");
     * map.set("baz", "bar");
     * const keys = map.keys(); // ["foo", "baz"]
     * ```
     * @returns {any[]}
     */
    keys() {
        const ret = wasm.loromap_keys(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * "Map"
     * @returns {'Map'}
     */
    kind() {
        const ret = wasm.loromap_kind(this.__wbg_ptr);
        return ret;
    }
    /**
     * Get the size of the map.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const map = doc.getMap("map");
     * map.set("foo", "bar");
     * console.log(map.size);   // 1
     * ```
     * @returns {number}
     */
    get size() {
        const ret = wasm.loromap_size(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Delete all key-value pairs in the map.
     */
    clear() {
        const ret = wasm.loromap_clear(this.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Remove the key from the map.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const map = doc.getMap("map");
     * map.set("foo", "bar");
     * map.delete("foo");
     * ```
     * @param {string} key
     */
    delete(key) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.loromap_delete(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Set the key with the value.
     *
     * If the value of the key is exist, the old value will be updated.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const map = doc.getMap("map");
     * map.set("foo", "bar");
     * map.set("foo", "baz");
     * ```
     * @param {string} key
     * @param {Value} value
     */
    set(key, value) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.loromap_set(this.__wbg_ptr, ptr0, len0, value);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Get the parent container.
     *
     * - The parent container of the root tree is `undefined`.
     * - The object returned is a new js object each time because it need to cross
     *   the WASM boundary.
     * @returns {Container | undefined}
     */
    parent() {
        const ret = wasm.loromap_parent(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the values of the map. If the value is a child container, the corresponding
     * `Container` will be returned.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const map = doc.getMap("map");
     * map.set("foo", "bar");
     * map.set("baz", "bar");
     * const values = map.values(); // ["bar", "bar"]
     * ```
     * @returns {any[]}
     */
    values() {
        const ret = wasm.loromap_values(this.__wbg_ptr);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Get the entries of the map. If the value is a child container, the corresponding
     * `Container` will be returned.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const map = doc.getMap("map");
     * map.set("foo", "bar");
     * map.set("baz", "bar");
     * const entries = map.entries(); // [["foo", "bar"], ["baz", "bar"]]
     * ```
     * @returns {([string, Value | Container])[]}
     */
    entries() {
        const ret = wasm.loromap_entries(this.__wbg_ptr);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Get the keys and the values. If the type of value is a child container,
     * it will be resolved recursively.
     *
     * @example
     * ```ts
     * import { LoroDoc, LoroText } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const map = doc.getMap("map");
     * map.set("foo", "bar");
     * const text = map.setContainer("text", new LoroText());
     * text.insert(0, "Hello");
     * console.log(map.toJSON());  // {"foo": "bar", "text": "Hello"}
     * ```
     * @returns {any}
     */
    toJSON() {
        const ret = wasm.loromap_toJSON(this.__wbg_ptr);
        return ret;
    }
    /**
     * Check if the container is deleted
     * @returns {boolean}
     */
    isDeleted() {
        const ret = wasm.loromap_isDeleted(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Subscribe to the changes of the map.
     *
     * Returns a subscription callback, which can be used to unsubscribe.
     *
     * The events will be emitted after a transaction is committed. A transaction is committed when:
     *
     * - `doc.commit()` is called.
     * - `doc.export(mode)` is called.
     * - `doc.import(data)` is called.
     * - `doc.checkout(version)` is called.
     *
     * @param {Listener} f - Event listener
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const map = doc.getMap("map");
     * map.subscribe((event)=>{
     *     console.log(event);
     * });
     * map.set("foo", "bar");
     * doc.commit();
     * ```
     * @param {Function} f
     * @returns {any}
     */
    subscribe(f) {
        const ret = wasm.loromap_subscribe(this.__wbg_ptr, f);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Convert this attached container and all descendants to an independent tree.
     * Text format applies recursively. Does not commit; throws for detached
     * containers, unsupported types, invalid options, or nesting above 256.
     * @param {ContainerTreeOptions | null} [opts]
     * @returns {ContainerNode}
     */
    toContainerTree(opts) {
        const ret = wasm.loromap_toContainerTree(this.__wbg_ptr, isLikeNone(opts) ? 0 : addToExternrefTable0(opts));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
module.exports.LoroMap = LoroMap;

const LoroMovableListFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_loromovablelist_free(ptr >>> 0, 1));
/**
 * The handler of a list container.
 *
 * Learn more at https://loro.dev/docs/tutorial/list
 */
class LoroMovableList {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(LoroMovableList.prototype);
        obj.__wbg_ptr = ptr;
        LoroMovableListFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        LoroMovableListFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_loromovablelist_free(ptr, 0);
    }
    /**
     * Whether the container is attached to a document.
     *
     * If it's detached, the operations on the container will not be persisted.
     * @returns {boolean}
     */
    isAttached() {
        const ret = wasm.lorolist_isAttached(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Get the creator of the list item at the given position.
     * @param {number} pos
     * @returns {PeerID | undefined}
     */
    getCreatorAt(pos) {
        const ret = wasm.loromovablelist_getCreatorAt(this.__wbg_ptr, pos);
        return ret;
    }
    /**
     * Get the attached container associated with this.
     *
     * Returns an attached `Container` that equals to this or created by this, otherwise `undefined`.
     * @returns {LoroList | undefined}
     */
    getAttached() {
        const ret = wasm.loromovablelist_getAttached(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Set the container at the given position.
     * @param {number} pos
     * @param {Container} child
     * @returns {Container}
     */
    setContainer(pos, child) {
        const ret = wasm.loromovablelist_setContainer(this.__wbg_ptr, pos, child);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the last mover of the list item at the given position.
     * @param {number} pos
     * @returns {PeerID | undefined}
     */
    getLastMoverAt(pos) {
        const ret = wasm.loromovablelist_getLastMoverAt(this.__wbg_ptr, pos);
        return ret;
    }
    /**
     * Push a container to the end of the list.
     * @param {Container} child
     * @returns {Container}
     */
    pushContainer(child) {
        const ret = wasm.loromovablelist_pushContainer(this.__wbg_ptr, child);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the last editor of the list item at the given position.
     * @param {number} pos
     * @returns {PeerID | undefined}
     */
    getLastEditorAt(pos) {
        const ret = wasm.loromovablelist_getLastEditorAt(this.__wbg_ptr, pos);
        return ret;
    }
    /**
     * Get the deep value of the elements in the range `[start, end)`.
     *
     * Each child container in the range is recursively resolved to its deep
     * value. Negative bounds are clamped to 0 and out-of-range bounds are
     * clamped to the list length; an empty or inverted range returns `[]`.
     *
     * @example
     * ```ts
     * import { LoroDoc, LoroText } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getMovableList("list");
     * list.insert(0, 100);
     * const text = list.insertContainer(1, new LoroText());
     * text.insert(0, "Hello");
     * console.log(list.getRangeValue(0, 2));  // [100, "Hello"]
     * ```
     * @param {number} start
     * @param {number} end
     * @returns {any}
     */
    getRangeValue(start, end) {
        const ret = wasm.loromovablelist_getRangeValue(this.__wbg_ptr, start, end);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Insert a container at the index.
     *
     * @example
     * ```ts
     * import { LoroDoc, LoroText } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getList("list");
     * list.insert(0, 100);
     * const text = list.insertContainer(1, new LoroText());
     * text.insert(0, "Hello");
     * console.log(list.toJSON());  // [100, "Hello"];
     * ```
     * @param {number} index
     * @param {Container} child
     * @returns {Container}
     */
    insertContainer(index, child) {
        const ret = wasm.loromovablelist_insertContainer(this.__wbg_ptr, index, child);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the shallow value of the movable list.
     *
     * Unlike `toJSON()` which recursively resolves all containers to their values,
     * `getShallowValue()` returns container IDs as strings for any nested containers.
     *
     * ```js
     * const doc = new LoroDoc();
     * doc.setPeerId("1");
     * const list = doc.getMovableList("list");
     * list.insert(0, 1);
     * list.insert(1, "two");
     * const subList = list.insertContainer(2, new LoroList());
     * subList.insert(0, "sub");
     * list.getShallowValue(); // [1, "two", "cid:2@1:List"]
     * list.toJSON(); // [1, "two", ["sub"]]
     * ```
     * @returns {Value[]}
     */
    getShallowValue() {
        const ret = wasm.loromovablelist_getShallowValue(this.__wbg_ptr);
        return ret;
    }
    /**
     * Get the deep value of the movable list with its container id.
     *
     * The result is a `{ cid, value }` object, where `cid` is the container id
     * string (the same as `list.id`) and `value` is the deep value of the
     * list. Child containers inside `value` are recursively replaced by their
     * own `{ cid, value }` nodes. This is the same node shape that
     * `LoroDoc.getDeepValueWithID()` emits for every container.
     *
     * @example
     * ```ts
     * import { LoroDoc, LoroText } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getMovableList("list");
     * list.insert(0, 100);
     * const text = list.insertContainer(1, new LoroText());
     * text.insert(0, "Hello");
     * console.log(list.getDeepValueWithID());
     * // { cid: "cid:root-list:MovableList",
     * //   value: [100, { cid: "cid:0@1:Text", value: "Hello" }] }
     * ```
     * @returns {any}
     */
    getDeepValueWithID() {
        const ret = wasm.loromovablelist_getDeepValueWithID(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the deep value of the elements in the range `[start, end)`, with
     * container ids.
     *
     * Each child container in the range is recursively replaced by its own
     * `{ cid, value }` node. Negative bounds are clamped to 0 and
     * out-of-range bounds are clamped to the list length; an empty or
     * inverted range returns `[]`.
     *
     * @example
     * ```ts
     * import { LoroDoc, LoroText } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getMovableList("list");
     * list.insert(0, 100);
     * const text = list.insertContainer(1, new LoroText());
     * text.insert(0, "Hello");
     * console.log(list.getRangeDeepValueWithID(0, 2));
     * // [100, { cid: "cid:0@1:Text", value: "Hello" }]
     * ```
     * @param {number} start
     * @param {number} end
     * @returns {any}
     */
    getRangeDeepValueWithID(start, end) {
        const ret = wasm.loromovablelist_getRangeDeepValueWithID(this.__wbg_ptr, start, end);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the id of this container.
     * @returns {ContainerID}
     */
    get id() {
        const ret = wasm.loromovablelist_id(this.__wbg_ptr);
        return ret;
    }
    /**
     * Get the value at the index. If the value is a container, the corresponding handler will be returned.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getList("list");
     * list.insert(0, 100);
     * console.log(list.get(0));  // 100
     * console.log(list.get(1));  // undefined
     * ```
     * @param {number} index
     * @returns {Value | Container | undefined}
     */
    get(index) {
        const ret = wasm.loromovablelist_get(this.__wbg_ptr, index);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Move the element from `from` to `to`.
     *
     * The new position of the element will be `to`.
     * Move the element from `from` to `to`.
     *
     * The new position of the element will be `to`. This method is optimized to prevent redundant
     * operations that might occur with a naive remove and insert approach. Specifically, it avoids
     * creating surplus values in the list, unlike a delete followed by an insert, which can lead to
     * additional values in cases of concurrent edits. This ensures more efficient and accurate
     * operations in a MovableList.
     * @param {number} from
     * @param {number} to
     */
    move(from, to) {
        const ret = wasm.loromovablelist_move(this.__wbg_ptr, from, to);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Create a new detached LoroMovableList (not attached to any LoroDoc).
     *
     * The edits on a detached container will not be persisted.
     * To attach the container to the document, please insert it into an attached container.
     */
    constructor() {
        const ret = wasm.loromovablelist_new();
        this.__wbg_ptr = ret >>> 0;
        LoroMovableListFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Pop a value from the end of the list.
     * @returns {Value | undefined}
     */
    pop() {
        const ret = wasm.loromovablelist_pop(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Set the value at the given position.
     *
     * It's different from `delete` + `insert` that it will replace the value at the position.
     *
     * For example, if you have a list `[1, 2, 3]`, and you call `set(1, 100)`, the list will be `[1, 100, 3]`.
     * If concurrently someone call `set(1, 200)`, the list will be `[1, 200, 3]` or `[1, 100, 3]`.
     *
     * But if you use `delete` + `insert` to simulate the set operation, they may create redundant operations
     * and the final result will be `[1, 100, 200, 3]` or `[1, 200, 100, 3]`.
     * @param {number} pos
     * @param {Value} value
     */
    set(pos, value) {
        const ret = wasm.loromovablelist_set(this.__wbg_ptr, pos, value);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * "MovableList"
     * @returns {'MovableList'}
     */
    kind() {
        const ret = wasm.loromovablelist_kind(this.__wbg_ptr);
        return ret;
    }
    /**
     * Push a value to the end of the list.
     * @param {Value} value
     */
    push(value) {
        const ret = wasm.loromovablelist_push(this.__wbg_ptr, value);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Delete all elements in the list.
     */
    clear() {
        const ret = wasm.loromovablelist_clear(this.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Delete elements from index to index + len.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getList("list");
     * list.insert(0, 100);
     * list.delete(0, 1);
     * console.log(list.value);  // []
     * ```
     * @param {number} index
     * @param {number} len
     */
    delete(index, len) {
        const ret = wasm.loromovablelist_delete(this.__wbg_ptr, index, len);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Insert a value at index.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getList("list");
     * list.insert(0, 100);
     * list.insert(1, "foo");
     * list.insert(2, true);
     * console.log(list.value);  // [100, "foo", true];
     * ```
     * @param {number} index
     * @param {Value} value
     */
    insert(index, value) {
        const ret = wasm.loromovablelist_insert(this.__wbg_ptr, index, value);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Get the length of list.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getList("list");
     * list.insert(0, 100);
     * list.insert(1, "foo");
     * list.insert(2, true);
     * console.log(list.length);  // 3
     * ```
     * @returns {number}
     */
    get length() {
        const ret = wasm.loromovablelist_length(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Get the parent container.
     *
     * - The parent container of the root tree is `undefined`.
     * - The object returned is a new js object each time because it need to cross
     *   the WASM boundary.
     * @returns {Container | undefined}
     */
    parent() {
        const ret = wasm.loromovablelist_parent(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get elements of the list. If the type of a element is a container, it will be
     * resolved recursively.
     *
     * @example
     * ```ts
     * import { LoroDoc, LoroText } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getList("list");
     * list.insert(0, 100);
     * const text = list.insertContainer(1, new LoroText());
     * text.insert(0, "Hello");
     * console.log(list.toJSON());  // [100, "Hello"];
     * ```
     * @returns {any}
     */
    toJSON() {
        const ret = wasm.loromovablelist_toJSON(this.__wbg_ptr);
        return ret;
    }
    /**
     * Get elements of the list. If the value is a child container, the corresponding
     * `Container` will be returned.
     *
     * @example
     * ```ts
     * import { LoroDoc, LoroText } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getList("list");
     * list.insert(0, 100);
     * list.insert(1, "foo");
     * list.insert(2, true);
     * list.insertContainer(3, new LoroText());
     * console.log(list.value);  // [100, "foo", true, LoroText];
     * ```
     * @returns {(Value | Container)[]}
     */
    toArray() {
        const ret = wasm.loromovablelist_toArray(this.__wbg_ptr);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Get the cursor of the container.
     * @param {number} pos
     * @param {Side} side
     * @returns {Cursor | undefined}
     */
    getCursor(pos, side) {
        const ret = wasm.loromovablelist_getCursor(this.__wbg_ptr, pos, side);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] === 0 ? undefined : Cursor.__wrap(ret[0]);
    }
    /**
     * Check if the container is deleted
     * @returns {boolean}
     */
    isDeleted() {
        const ret = wasm.loromovablelist_isDeleted(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Subscribe to the changes of the list.
     *
     * Returns a subscription callback, which can be used to unsubscribe.
     *
     * The events will be emitted after a transaction is committed. A transaction is committed when:
     *
     * - `doc.commit()` is called.
     * - `doc.export(mode)` is called.
     * - `doc.import(data)` is called.
     * - `doc.checkout(version)` is called.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const list = doc.getList("list");
     * list.subscribe((event)=>{
     *     console.log(event);
     * });
     * list.insert(0, 100);
     * doc.commit();
     * ```
     * @param {Function} f
     * @returns {any}
     */
    subscribe(f) {
        const ret = wasm.loromovablelist_subscribe(this.__wbg_ptr, f);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Convert this attached container and all descendants to an independent tree.
     * Text format applies recursively. Does not commit; throws for detached
     * containers, unsupported types, invalid options, or nesting above 256.
     * @param {ContainerTreeOptions | null} [opts]
     * @returns {ContainerNode}
     */
    toContainerTree(opts) {
        const ret = wasm.loromovablelist_toContainerTree(this.__wbg_ptr, isLikeNone(opts) ? 0 : addToExternrefTable0(opts));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Read [start,end), clamped to list length. Inverted bounds return no items.
     * Returns actual start, totalLength and items; this is not a complete container.
     * Only selected descendants are traversed; parent shallow list access is O(N).
     * @param {number} start
     * @param {number} end
     * @param {ContainerTreeOptions | null} [opts]
     * @returns {ContainerTreeSlice}
     */
    toContainerTreeSlice(start, end, opts) {
        const ret = wasm.loromovablelist_toContainerTreeSlice(this.__wbg_ptr, start, end, isLikeNone(opts) ? 0 : addToExternrefTable0(opts));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
module.exports.LoroMovableList = LoroMovableList;

const LoroTextFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_lorotext_free(ptr >>> 0, 1));
/**
 * The handler of a text container. It supports rich text CRDT.
 *
 * Learn more at https://loro.dev/docs/tutorial/text
 */
class LoroText {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(LoroText.prototype);
        obj.__wbg_ptr = ptr;
        LoroTextFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        LoroTextFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_lorotext_free(ptr, 0);
    }
    /**
     * Change the state of this text by delta.
     *
     * If a delta item is `insert`, it should include all the attributes of the inserted text.
     * Loro's rich text CRDT may make the inserted text inherit some styles when you use
     * `insert` method directly. However, when you use `applyDelta` if some attributes are
     * inherited from CRDT but not included in the delta, they will be removed.
     *
     * Another special property of `applyDelta` is if you format an attribute for ranges out of
     * the text length, Loro will insert new lines to fill the gap first. It's useful when you
     * build the binding between Loro and rich text editors like Quill, which might assume there
     * is always a newline at the end of the text implicitly.
     *
     * @example
     * ```ts
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * doc.configTextStyle({bold: {expand: "after"}});
     * text.insert(0, "Hello World!");
     * text.mark({ start: 0, end: 5 }, "bold", true);
     * const delta = text.toDelta();
     * const text2 = doc.getText("text2");
     * text2.applyDelta(delta);
     * expect(text2.toDelta()).toStrictEqual(delta);
     * ```
     * @param {Delta<string>[]} delta
     */
    applyDelta(delta) {
        const ret = wasm.lorotext_applyDelta(this.__wbg_ptr, delta);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Convert a position between coordinate systems.
     *
     * Supported values: `"unicode"`, `"utf16"`, `"utf8"`.
     *
     * Returns `undefined` when out of bounds or unsupported.
     * @param {number} index
     * @param {string} from
     * @param {string} to
     * @returns {any}
     */
    convertPos(index, from, to) {
        const ptr0 = passStringToWasm0(from, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(to, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.lorotext_convertPos(this.__wbg_ptr, index, ptr0, len0, ptr1, len1);
        return ret;
    }
    /**
     * Delete elements from index to utf-8 index + len
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * text.insertUtf8(0, "Hello");
     * text.deleteUtf8(1, 3);
     * const s = text.toString();
     * console.log(s); // "Ho"
     * ```
     * @param {number} index
     * @param {number} len
     */
    deleteUtf8(index, len) {
        const ret = wasm.lorotext_deleteUtf8(this.__wbg_ptr, index, len);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Get the editor of the text at the given position.
     *
     * Returns `undefined` if the position is out of range.
     * @param {number} pos
     * @returns {PeerID | undefined}
     */
    getEditorOf(pos) {
        const ret = wasm.lorotext_getEditorOf(this.__wbg_ptr, pos);
        return ret;
    }
    /**
     * Insert some string at utf-8 index.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * text.insertUtf8(0, "Hello");
     * ```
     * @param {number} index
     * @param {string} content
     */
    insertUtf8(index, content) {
        const ptr0 = passStringToWasm0(content, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.lorotext_insertUtf8(this.__wbg_ptr, index, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Whether the container is attached to a LoroDoc.
     *
     * If it's detached, the operations on the container will not be persisted.
     * @returns {boolean}
     */
    isAttached() {
        const ret = wasm.lorolist_isAttached(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Get the rich text delta in the given range (utf-16 index).
     * @param {number} start
     * @param {number} end
     * @returns {Delta<string>[]}
     */
    sliceDelta(start, end) {
        const ret = wasm.lorotext_sliceDelta(this.__wbg_ptr, start, end);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the attached container associated with this.
     *
     * Returns an attached `Container` that is equal to this or created by this; otherwise, it returns `undefined`.
     * @returns {LoroText | undefined}
     */
    getAttached() {
        const ret = wasm.lorotext_getAttached(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Update the current text to the target text, the difference is calculated line by line.
     *
     * It uses Myers' diff algorithm to compute the optimal difference.
     * @param {string} text
     * @param {any} options
     */
    updateByLine(text, options) {
        const ptr0 = passStringToWasm0(text, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.lorotext_updateByLine(this.__wbg_ptr, ptr0, len0, options);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Get the rich text delta in the given range (utf-8 index).
     * @param {number} start
     * @param {number} end
     * @returns {Delta<string>[]}
     */
    sliceDeltaUtf8(start, end) {
        const ret = wasm.lorotext_sliceDeltaUtf8(this.__wbg_ptr, start, end);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the shallow value of the text. This equals to `text.toString()`.
     * @returns {string}
     */
    getShallowValue() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.lorotext_getShallowValue(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Get the deep value of the text with its container id.
     *
     * The result is a `{ cid, value }` object, where `cid` is the container id
     * string (the same as `text.id`) and `value` is the text content. This is
     * the same node shape that `LoroDoc.getDeepValueWithID()` emits for every
     * container.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * text.insert(0, "Hello");
     * console.log(text.getDeepValueWithID());  // { cid: "cid:root-text:Text", value: "Hello" }
     * ```
     * @returns {any}
     */
    getDeepValueWithID() {
        const ret = wasm.lorotext_getDeepValueWithID(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the container id of the text.
     * @returns {ContainerID}
     */
    get id() {
        const ret = wasm.lorotext_id(this.__wbg_ptr);
        return ret;
    }
    /**
     * Create a new detached LoroText (not attached to any LoroDoc).
     *
     * The edits on a detached container will not be persisted.
     * To attach the container to the document, please insert it into an attached container.
     */
    constructor() {
        const ret = wasm.lorotext_new();
        this.__wbg_ptr = ret >>> 0;
        LoroTextFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Iterate each text span(internal storage unit)
     *
     * The callback function will be called for each span in the text.
     * If the callback returns `false`, the iteration will stop.
     *
     * The current text chunks are snapshotted before callbacks run, so the callback
     * may read or mutate the document without re-entering internal state locks.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * text.insert(0, "Hello");
     * text.iter((str) => (console.log(str), true));
     * ```
     * @param {(string) => boolean} callback
     */
    iter(callback) {
        const ret = wasm.lorotext_iter(this.__wbg_ptr, callback);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * "Text"
     * @returns {'Text'}
     */
    kind() {
        const ret = wasm.lorotext_kind(this.__wbg_ptr);
        return ret;
    }
    /**
     * Mark a range of text with a key and a value (utf-16 index).
     *
     * > You should call `configTextStyle` before using `mark` and `unmark`.
     *
     * You can use it to create a highlight, make a range of text bold, or add a link to a range of text.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * doc.configTextStyle({bold: {expand: "after"}});
     * const text = doc.getText("text");
     * text.insert(0, "Hello World!");
     * text.mark({ start: 0, end: 5 }, "bold", true);
     * ```
     * @param {{ start: number, end: number }} range
     * @param {string} key
     * @param {any} value
     */
    mark(range, key, value) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.lorotext_mark(this.__wbg_ptr, range, ptr0, len0, value);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Push a string to the end of the text.
     * @param {string} s
     */
    push(s) {
        const ptr0 = passStringToWasm0(s, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.lorotext_push(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Get a string slice (utf-16 index).
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * text.insert(0, "Hello");
     * text.slice(0, 2); // "He"
     * ```
     * @param {number} start_index
     * @param {number} end_index
     * @returns {string}
     */
    slice(start_index, end_index) {
        let deferred2_0;
        let deferred2_1;
        try {
            const ret = wasm.lorotext_slice(this.__wbg_ptr, start_index, end_index);
            var ptr1 = ret[0];
            var len1 = ret[1];
            if (ret[3]) {
                ptr1 = 0; len1 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred2_0 = ptr1;
            deferred2_1 = len1;
            return getStringFromWasm0(ptr1, len1);
        } finally {
            wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
        }
    }
    /**
     * Delete elements from index to index + len (utf-16 index).
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * text.insert(0, "Hello");
     * text.delete(1, 3);
     * const s = text.toString();
     * console.log(s); // "Ho"
     * ```
     * @param {number} index
     * @param {number} len
     */
    delete(index, len) {
        const ret = wasm.lorotext_delete(this.__wbg_ptr, index, len);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Insert the string at the given index (utf-16 index).
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * text.insert(0, "Hello");
     * ```
     * @param {number} index
     * @param {string} content
     */
    insert(index, content) {
        const ptr0 = passStringToWasm0(content, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.lorotext_insert(this.__wbg_ptr, index, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Get the length of text (utf-16 length).
     * @returns {number}
     */
    get length() {
        const ret = wasm.lorotext_length(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Get the parent container.
     *
     * - The parent of the root is `undefined`.
     * - The object returned is a new js object each time because it need to cross
     *   the WASM boundary.
     * @returns {Container | undefined}
     */
    parent() {
        const ret = wasm.lorotext_parent(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Delete and return the string at the given range and insert a string at the same position (utf-16 index).
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * text.insert(0, "Hello");
     * text.splice(2, 3, "llo"); // "llo"
     * ```
     * @param {number} pos
     * @param {number} len
     * @param {string} s
     * @returns {string}
     */
    splice(pos, len, s) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(s, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.lorotext_splice(this.__wbg_ptr, pos, len, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * Unmark a range of text with a key and a value (utf-16 index).
     *
     * > You should call `configTextStyle` before using `mark` and `unmark`.
     *
     * You can use it to remove highlights, bolds or links
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * doc.configTextStyle({bold: {expand: "after"}});
     * const text = doc.getText("text");
     * text.insert(0, "Hello World!");
     * text.mark({ start: 0, end: 5 }, "bold", true);
     * text.unmark({ start: 0, end: 5 }, "bold");
     * ```
     * @param {{ start: number, end: number }} range
     * @param {string} key
     */
    unmark(range, key) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.lorotext_unmark(this.__wbg_ptr, range, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Update the current text to the target text.
     *
     * It will calculate the minimal difference and apply it to the current text.
     * It uses Myers' diff algorithm to compute the optimal difference.
     *
     * This could take a long time for large texts (e.g. > 50_000 characters).
     * In that case, you should use `updateByLine` instead.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * text.insert(0, "Hello");
     * text.update("Hello World");
     * console.log(text.toString()); // "Hello World"
     * ```
     * @param {string} text
     * @param {any} options
     */
    update(text, options) {
        const ptr0 = passStringToWasm0(text, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.lorotext_update(this.__wbg_ptr, ptr0, len0, options);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Get the character at the given position (utf-16 index).
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * text.insert(0, "Hello");
     * text.charAt(0); // "H"
     * ```
     * @param {number} pos
     * @returns {string}
     */
    charAt(pos) {
        const ret = wasm.lorotext_charAt(this.__wbg_ptr, pos);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return String.fromCodePoint(ret[0]);
    }
    /**
     * Get the JSON representation of the text.
     * @returns {any}
     */
    toJSON() {
        const ret = wasm.lorotext_toJSON(this.__wbg_ptr);
        return ret;
    }
    /**
     * Get the text in [Delta](https://quilljs.com/docs/delta/) format.
     *
     * The returned value will include the rich text information.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const text = doc.getText("text");
     * doc.configTextStyle({bold: {expand: "after"}});
     * text.insert(0, "Hello World!");
     * text.mark({ start: 0, end: 5 }, "bold", true);
     * console.log(text.toDelta());  // [ { insert: 'Hello', attributes: { bold: true } } ]
     * ```
     * @returns {Delta<string>[]}
     */
    toDelta() {
        const ret = wasm.lorotext_toDelta(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the cursor at the given position.
     *
     * - The first argument is the position (utf16-index).
     * - The second argument is the side: `-1` for left, `0` for middle, `1` for right.
     * @param {number} pos
     * @param {Side} side
     * @returns {Cursor | undefined}
     */
    getCursor(pos, side) {
        const ret = wasm.lorotext_getCursor(this.__wbg_ptr, pos, side);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] === 0 ? undefined : Cursor.__wrap(ret[0]);
    }
    /**
     * Check if the container is deleted
     * @returns {boolean}
     */
    isDeleted() {
        const ret = wasm.lorotext_isDeleted(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Subscribe to the changes of the text.
     *
     * The events will be emitted after a transaction is committed. A transaction is committed when:
     *
     * - `doc.commit()` is called.
     * - `doc.export(mode)` is called.
     * - `doc.import(data)` is called.
     * - `doc.checkout(version)` is called.
     *
     * returns a subscription callback, which can be used to unsubscribe.
     * @param {Function} f
     * @returns {any}
     */
    subscribe(f) {
        const ret = wasm.lorotext_subscribe(this.__wbg_ptr, f);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Convert the text to a string
     * @returns {string}
     */
    toString() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.lorotext_toString(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Convert this attached container and all descendants to an independent tree.
     * Text format applies recursively. Does not commit; throws for detached
     * containers, unsupported types, invalid options, or nesting above 256.
     * @param {ContainerTreeOptions | null} [opts]
     * @returns {ContainerNode}
     */
    toContainerTree(opts) {
        const ret = wasm.lorotext_toContainerTree(this.__wbg_ptr, isLikeNone(opts) ? 0 : addToExternrefTable0(opts));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
module.exports.LoroText = LoroText;

const LoroTreeFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_lorotree_free(ptr >>> 0, 1));
/**
 * The handler of a tree(forest) container.
 *
 * Learn more at https://loro.dev/docs/tutorial/tree
 */
class LoroTree {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(LoroTree.prototype);
        obj.__wbg_ptr = ptr;
        LoroTreeFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        LoroTreeFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_lorotree_free(ptr, 0);
    }
    /**
     * Create a new tree node as the child of parent and return a `LoroTreeNode` instance.
     * If the parent is undefined, the tree node will be a root node.
     *
     * If the index is not provided, the new node will be appended to the end.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const tree = doc.getTree("tree");
     * const root = tree.createNode();
     * const node = tree.createNode(undefined, 0);
     *
     * //  undefined
     * //    /   \
     * // node  root
     * ```
     * @param {TreeID | undefined} parent
     * @param {number | null} [index]
     * @returns {LoroTreeNode}
     */
    createNode(parent, index) {
        const ret = wasm.lorotree_createNode(this.__wbg_ptr, parent, isLikeNone(index) ? 0x100000001 : (index) >>> 0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return LoroTreeNode.__wrap(ret[0]);
    }
    /**
     * Whether the container is attached to a document.
     *
     * If it's detached, the operations on the container will not be persisted.
     * @returns {boolean}
     */
    isAttached() {
        const ret = wasm.lorolist_isAttached(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Get the attached container associated with this.
     *
     * Returns an attached `Container` that equals to this or created by this, otherwise `undefined`.
     * @returns {LoroTree | undefined}
     */
    getAttached() {
        const ret = wasm.lorotree_getAttached(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get LoroTreeNode by the TreeID.
     * @param {TreeID} target
     * @returns {LoroTreeNode | undefined}
     */
    getNodeByID(target) {
        const ret = wasm.lorotree_getNodeByID(this.__wbg_ptr, target);
        return ret === 0 ? undefined : LoroTreeNode.__wrap(ret);
    }
    /**
     * Return `None` if the node is not exist, otherwise return `Some(true)` if the node is deleted.
     * @param {TreeID} target
     * @returns {boolean}
     */
    isNodeDeleted(target) {
        const ret = wasm.lorotree_isNodeDeleted(this.__wbg_ptr, target);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    /**
     * Get the shallow value of the tree.
     *
     * Unlike `toJSON()` which recursively resolves nested containers to their values,
     * `getShallowValue()` returns container IDs as strings for any nested containers.
     *
     * @example
     * ```ts
     * const doc = new LoroDoc();
     * doc.setPeerId("1");
     * const tree = doc.getTree("tree");
     * const root = tree.createNode();
     * root.data.set("name", "root");
     * const text = root.data.setContainer("content", new LoroText());
     * text.insert(0, "Hello");
     *
     * console.log(tree.getShallowValue());
     * // [{
     * //   id: "0@1",
     * //   parent: null,
     * //   index: 0,
     * //   fractional_index: "80",
     * //   meta: "cid:0@1:Map",
     * //   children: []
     * // }]
     *
     * console.log(tree.toJSON());
     * // [{
     * //   id: "0@1",
     * //   parent: null,
     * //   index: 0,
     * //   fractional_index: "80",
     * //   meta: {
     * //     name: "root",
     * //     content: "Hello"
     * //   },
     * //   children: []
     * // }]
     * ```
     * @returns {TreeNodeShallowValue[]}
     */
    getShallowValue() {
        const ret = wasm.lorotree_getShallowValue(this.__wbg_ptr);
        return ret;
    }
    /**
     * Get the deep value of the tree with its container id.
     *
     * The result is a `{ cid, value }` object, where `cid` is the container id
     * string (the same as `tree.id`) and `value` is the deep value of the
     * tree (each node's `meta` is the deep value of its associated metadata
     * map). This is the same node shape that `LoroDoc.getDeepValueWithID()`
     * emits for every container.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const tree = doc.getTree("tree");
     * const root = tree.createNode();
     * root.data.set("color", "red");
     * console.log(tree.getDeepValueWithID());
     * // { cid: "cid:root-tree:Tree",
     * //   value: [ { id: '0@1', parent: null, ..., meta: { color: 'red' }, children: [] } ] }
     * ```
     * @returns {any}
     */
    getDeepValueWithID() {
        const ret = wasm.lorotree_getDeepValueWithID(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Set whether to generate a fractional index for moving and creating.
     *
     * A fractional index can be used to determine the position of tree nodes among their siblings.
     *
     * The jitter is used to avoid conflicts when multiple users are creating a node at the same position.
     * A value of 0 is the default, which means no jitter; any value larger than 0 will enable jitter.
     *
     * Generally speaking, higher jitter value will increase the size of the operation
     * [Read more about it](https://www.loro.dev/blog/movable-tree#implementation-and-encoding-size)
     * @param {number} jitter
     */
    enableFractionalIndex(jitter) {
        wasm.lorotree_enableFractionalIndex(this.__wbg_ptr, jitter);
    }
    /**
     * Disable the fractional index generation when you don't need the Tree's siblings to be sorted.
     * The fractional index will always be set to the same default value 0.
     *
     * After calling this, you cannot use `tree.moveTo()`, `tree.moveBefore()`, `tree.moveAfter()`,
     * and `tree.createAt()`.
     */
    disableFractionalIndex() {
        wasm.lorotree_disableFractionalIndex(this.__wbg_ptr);
    }
    /**
     * Whether the tree enables the fractional index generation.
     * @returns {boolean}
     */
    isFractionalIndexEnabled() {
        const ret = wasm.lorotree_isFractionalIndexEnabled(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Get the id of the container.
     * @returns {ContainerID}
     */
    get id() {
        const ret = wasm.lorotree_id(this.__wbg_ptr);
        return ret;
    }
    /**
     * Move the target tree node to be a child of the parent.
     * It's not allowed that the target is an ancestor of the parent
     * or the target and the parent are the same node.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const tree = doc.getTree("tree");
     * const root = tree.createNode();
     * const node = root.createNode();
     * const node2 = node.createNode();
     * tree.move(node2.id, root.id);
     * // Error will be thrown if move operation creates a cycle
     * // tree.move(root.id, node.id);
     * ```
     * @param {TreeID} target
     * @param {TreeID | undefined} parent
     * @param {number | null} [index]
     */
    move(target, parent, index) {
        const ret = wasm.lorotree_move(this.__wbg_ptr, target, parent, isLikeNone(index) ? 0x100000001 : (index) >>> 0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Create a new detached LoroTree (not attached to any LoroDoc).
     *
     * The edits on a detached container will not be persisted.
     * To attach the container to the document, please insert it into an attached container.
     */
    constructor() {
        const ret = wasm.lorotree_new();
        this.__wbg_ptr = ret >>> 0;
        LoroTreeFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * "Tree"
     * @returns {'Tree'}
     */
    kind() {
        const ret = wasm.lorotree_kind(this.__wbg_ptr);
        return ret;
    }
    /**
     * Get all tree nodes of the forest, including deleted nodes.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const tree = doc.getTree("tree");
     * const root = tree.createNode();
     * const node = root.createNode();
     * const node2 = node.createNode();
     * console.log(tree.nodes());
     * ```
     * @returns {LoroTreeNode[]}
     */
    nodes() {
        const ret = wasm.lorotree_nodes(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Get the root nodes of the forest.
     * @returns {LoroTreeNode[]}
     */
    roots() {
        const ret = wasm.lorotree_roots(this.__wbg_ptr);
        var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v1;
    }
    /**
     * Delete a tree node from the forest.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const tree = doc.getTree("tree");
     * const root = tree.createNode();
     * const node = root.createNode();
     * tree.delete(node.id);
     * ```
     * @param {TreeID} target
     */
    delete(target) {
        const ret = wasm.lorotree_delete(this.__wbg_ptr, target);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Get the parent container of the tree container.
     *
     * - The parent container of the root tree is `undefined`.
     * - The object returned is a new js object each time because it need to cross
     *   the WASM boundary.
     * @returns {Container | undefined}
     */
    parent() {
        const ret = wasm.lorotree_parent(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the hierarchy array with metadata of the forest.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const tree = doc.getTree("tree");
     * const root = tree.createNode();
     * root.data.set("color", "red");
     * // [ { id: '0@F2462C4159C4C8D1', parent: null, meta: { color: 'red' }, children: [] } ]
     * console.log(tree.toJSON());
     * ```
     * @returns {any}
     */
    toJSON() {
        const ret = wasm.lorotree_toJSON(this.__wbg_ptr);
        return ret;
    }
    /**
     * Return `true` if the tree contains the TreeID, include deleted node.
     * @param {TreeID} target
     * @returns {boolean}
     */
    has(target) {
        const ret = wasm.lorotree_has(this.__wbg_ptr, target);
        return ret !== 0;
    }
    /**
     * Get the hierarchy array of the forest.
     *
     * Note: the metadata will be not resolved. So if you don't only care about hierarchy
     * but also the metadata, you should use `toJson()`.
     * @returns {Array<any>}
     */
    toArray() {
        const ret = wasm.lorotree_toArray(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the flat array of the forest. If `with_deleted` is true, the deleted nodes will be included.
     * @param {{ withDeleted: boolean }} options
     * @returns {Array<any>}
     */
    getNodes(options) {
        const ret = wasm.lorotree_getNodes(this.__wbg_ptr, options);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Check if the container is deleted
     * @returns {boolean}
     */
    isDeleted() {
        const ret = wasm.lorotree_isDeleted(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Subscribe to the changes of the tree.
     *
     * Returns a subscription callback, which can be used to unsubscribe.
     *
     * Trees have three types of events: `create`, `delete`, and `move`.
     * - `create`: Creates a new node with its `target` TreeID. If `parent` is undefined,
     *             a root node is created; otherwise, a child node of `parent` is created.
     *             If the node being created was previously deleted and has archived child nodes,
     *             create events for these child nodes will also be received.
     * - `delete`: Deletes the target node. The structure and state of the target node and
     *             its child nodes are archived, and delete events for the child nodes will not be received.
     * - `move`:   Moves the target node. If `parent` is undefined, the target node becomes a root node;
     *             otherwise, it becomes a child node of `parent`.
     *
     * If a tree container is subscribed, the event of metadata changes will also be received as a MapDiff.
     * And event's `path` will end with `TreeID`.
     *
     * The events will be emitted after a transaction is committed. A transaction is committed when:
     *
     * - `doc.commit()` is called.
     * - `doc.export(mode)` is called.
     * - `doc.import(data)` is called.
     * - `doc.checkout(version)` is called.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const tree = doc.getTree("tree");
     * tree.subscribe((event)=>{
     *     // event.type: "create" | "delete" | "move"
     * });
     * const root = tree.createNode();
     * const node = root.createNode();
     * doc.commit();
     * ```
     * @param {Function} f
     * @returns {any}
     */
    subscribe(f) {
        const ret = wasm.lorotree_subscribe(this.__wbg_ptr, f);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Convert this attached container and all descendants to an independent tree.
     * Text format applies recursively. Does not commit; throws for detached
     * containers, unsupported types, invalid options, or nesting above 256.
     * @param {ContainerTreeOptions | null} [opts]
     * @returns {ContainerNode}
     */
    toContainerTree(opts) {
        const ret = wasm.lorotree_toContainerTree(this.__wbg_ptr, isLikeNone(opts) ? 0 : addToExternrefTable0(opts));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
module.exports.LoroTree = LoroTree;

const LoroTreeNodeFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_lorotreenode_free(ptr >>> 0, 1));
/**
 * The handler of a tree node.
 */
class LoroTreeNode {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(LoroTreeNode.prototype);
        obj.__wbg_ptr = ptr;
        LoroTreeNodeFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        LoroTreeNodeFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_lorotreenode_free(ptr, 0);
    }
    /**
     * @returns {string}
     */
    __getClassname() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.lorotreenode___getClassname(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Get the creation id of this node.
     * @returns {{ peer: PeerID, counter: number }}
     */
    creationId() {
        const ret = wasm.lorotreenode_creationId(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Check if the node is deleted.
     * @returns {boolean}
     */
    isDeleted() {
        const ret = wasm.lorotreenode_isDeleted(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    /**
     * Move the tree node to be before the target node.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const tree = doc.getTree("tree");
     * const root = tree.createNode();
     * const node = root.createNode();
     * const node2 = root.createNode();
     * node2.moveBefore(node);
     * //   root
     * //  /    \
     * // node2 node
     * ```
     * @param {LoroTreeNode} target
     */
    moveBefore(target) {
        _assertClass(target, LoroTreeNode);
        const ret = wasm.lorotreenode_moveBefore(this.__wbg_ptr, target.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Create a new node as the child of the current node and
     * return an instance of `LoroTreeNode`.
     *
     * If the index is not provided, the new node will be appended to the end.
     *
     * @example
     * ```typescript
     * import { LoroDoc } from "loro-crdt";
     *
     * let doc = new LoroDoc();
     * let tree = doc.getTree("tree");
     * let root = tree.createNode();
     * let node = root.createNode();
     * let node2 = root.createNode(0);
     * //    root
     * //    /  \
     * // node2 node
     * ```
     * @param {number | null} [index]
     * @returns {LoroTreeNode}
     */
    createNode(index) {
        const ret = wasm.lorotreenode_createNode(this.__wbg_ptr, isLikeNone(index) ? 0x100000001 : (index) >>> 0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return LoroTreeNode.__wrap(ret[0]);
    }
    /**
     * Get the last mover of this node.
     * @returns {{ peer: PeerID, counter: number } | undefined}
     */
    getLastMoveId() {
        const ret = wasm.lorotreenode_getLastMoveId(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {any}
     */
    toJSON() {
        const ret = wasm.lorotreenode_toJSON(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Get the `Fractional Index` of the node.
     *
     * Note: the tree container must be attached to the document.
     * @returns {string | undefined}
     */
    fractionalIndex() {
        const ret = wasm.lorotreenode_fractionalIndex(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * The TreeID of the node.
     * @returns {TreeID}
     */
    get id() {
        const ret = wasm.lorotreenode_id(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {LoroTreeNode | undefined} parent
     * @param {number | null} [index]
     */
    move(parent, index) {
        const ret = wasm.lorotreenode_move(this.__wbg_ptr, parent, isLikeNone(index) ? 0x100000001 : (index) >>> 0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Get the associated metadata map container of a tree node.
     * @returns {LoroMap}
     */
    get data() {
        const ret = wasm.lorotreenode_data(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return LoroMap.__wrap(ret[0]);
    }
    /**
     * Get the index of the node in the parent's children.
     * @returns {number | undefined}
     */
    index() {
        const ret = wasm.lorotreenode_index(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] === 0x100000001 ? undefined : ret[0];
    }
    /**
     * @returns {LoroTreeNode | undefined}
     */
    parent() {
        const ret = wasm.lorotreenode_parent(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] === 0 ? undefined : LoroTreeNode.__wrap(ret[0]);
    }
    /**
     * Get the creator of this node.
     * @returns {PeerID}
     */
    creator() {
        const ret = wasm.lorotreenode_creator(this.__wbg_ptr);
        return ret;
    }
    /**
     * Get the children of this node.
     *
     * The objects returned are new js objects each time because they need to cross
     * the WASM boundary.
     * @returns {any}
     */
    children() {
        const ret = wasm.lorotreenode_children(this.__wbg_ptr);
        return ret;
    }
    /**
     * Move the tree node to be after the target node.
     *
     * @example
     * ```ts
     * import { LoroDoc } from "loro-crdt";
     *
     * const doc = new LoroDoc();
     * const tree = doc.getTree("tree");
     * const root = tree.createNode();
     * const node = root.createNode();
     * const node2 = root.createNode();
     * node2.moveAfter(node);
     * // root
     * //  /  \
     * // node node2
     * ```
     * @param {LoroTreeNode} target
     */
    moveAfter(target) {
        _assertClass(target, LoroTreeNode);
        const ret = wasm.lorotreenode_moveAfter(this.__wbg_ptr, target.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
}
module.exports.LoroTreeNode = LoroTreeNode;

const UndoManagerFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_undomanager_free(ptr >>> 0, 1));
/**
 * `UndoManager` is responsible for handling undo and redo operations.
 *
 * By default, the maxUndoSteps is set to 100, mergeInterval is set to 1000 ms.
 *
 * Each commit made by the current peer is recorded as an undo step in the `UndoManager`.
 * Undo steps can be merged if they occur within a specified merge interval.
 *
 * Note that undo operations are local and cannot revert changes made by other peers.
 * To undo changes made by other peers, consider using the time travel feature.
 *
 * Once the `peerId` is bound to the `UndoManager` in the document, it cannot be changed.
 * Otherwise, the `UndoManager` may not function correctly.
 */
class UndoManager {

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        UndoManagerFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_undomanager_free(ptr, 0);
    }
    groupStart() {
        const ret = wasm.undomanager_groupStart(this.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Get the value associated with the top redo stack item, if any.
     * Returns `undefined` if there is no redo item.
     * @returns {Value | undefined}
     */
    topRedoValue() {
        const ret = wasm.undomanager_topRedoValue(this.__wbg_ptr);
        return ret;
    }
    /**
     * Get the value associated with the top undo stack item, if any.
     * Returns `undefined` if there is no undo item.
     * @returns {Value | undefined}
     */
    topUndoValue() {
        const ret = wasm.undomanager_topUndoValue(this.__wbg_ptr);
        return ret;
    }
    /**
     * The number of max undo steps.
     * If the number of undo steps exceeds this number, the oldest undo step will be removed.
     * @param {number} steps
     */
    setMaxUndoSteps(steps) {
        wasm.undomanager_setMaxUndoSteps(this.__wbg_ptr, steps);
    }
    /**
     * Set the merge interval (in ms).
     *
     * If the interval is set to 0, the undo steps will not be merged.
     * Otherwise, the undo steps will be merged if the interval between the two steps is less than the given interval.
     * @param {number} interval
     */
    setMergeInterval(interval) {
        wasm.undomanager_setMergeInterval(this.__wbg_ptr, interval);
    }
    /**
     * If a local event's origin matches the given prefix, it will not be recorded in the
     * undo stack.
     * @param {string} prefix
     */
    addExcludeOriginPrefix(prefix) {
        const ptr0 = passStringToWasm0(prefix, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.undomanager_addExcludeOriginPrefix(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * `UndoManager` is responsible for handling undo and redo operations.
     *
     * PeerID cannot be changed during the lifetime of the UndoManager.
     *
     * Note that undo operations are local and cannot revert changes made by other peers.
     * To undo changes made by other peers, consider using the time travel feature.
     *
     * Each commit made by the current peer is recorded as an undo step in the `UndoManager`.
     * Undo steps can be merged if they occur within a specified merge interval.
     *
     * ## Config
     *
     * - `mergeInterval`: Optional. The interval in milliseconds within which undo steps can be merged. Default is 1000 ms.
     * - `maxUndoSteps`: Optional. The maximum number of undo steps to retain. Default is 100.
     * - `excludeOriginPrefixes`: Optional. An array of string prefixes. Events with origins matching these prefixes will be excluded from undo steps.
     * - `onPush`: Optional. A callback function that is called when an undo/redo step is pushed.
     *    The function can return a meta data value that will be attached to the given stack item.
     * - `onPop`: Optional. A callback function that is called when an undo/redo step is popped.
     *    The function will have a meta data value that was attached to the given stack item when
     *   `onPush` was called.
     * @param {LoroDoc} doc
     * @param {UndoConfig} config
     */
    constructor(doc, config) {
        _assertClass(doc, LoroDoc);
        const ret = wasm.undomanager_new(doc.__wbg_ptr, config);
        this.__wbg_ptr = ret >>> 0;
        UndoManagerFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Get the peer id of the undo manager.
     * @returns {PeerID}
     */
    peer() {
        const ret = wasm.undomanager_peer(this.__wbg_ptr);
        return ret;
    }
    /**
     * Redo the last undone operation.
     *
     * Throws like `undo` on steps that would recreate a container of an
     * unknown type.
     * @returns {boolean}
     */
    redo() {
        const ret = wasm.undomanager_redo(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    /**
     * Undo the last operation.
     *
     * Throws without changing the doc if the step would have to recreate a
     * container of a type unknown to this version (created by a newer
     * loro-crdt). That step, with every edit merged into it, is dropped and its
     * edits stay; the next call undoes the step before it, rebased over the
     * dropped step's edits like over a remote peer's.
     * @returns {boolean}
     */
    undo() {
        const ret = wasm.undomanager_undo(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    clear() {
        wasm.undomanager_clear(this.__wbg_ptr);
    }
    /**
     * Pause the UndoManager so that local edits and checkout events are ignored.
     *
     * While paused, local edits are not recorded as undo steps and checkout
     * events do not clear the stacks. Import events (remote changes) are still
     * processed so that the stacks remain correctly transformed against
     * concurrent edits.
     *
     * Use this before temporary checkouts (e.g. read-only history preview) that
     * should not disturb undo/redo history. Close any open group before pausing.
     *
     * Call `resume()` after returning the document to its original state.
     */
    pause() {
        wasm.undomanager_pause(this.__wbg_ptr);
    }
    /**
     * Resume the UndoManager after a `pause()`.
     */
    resume() {
        wasm.undomanager_resume(this.__wbg_ptr);
    }
    /**
     * Can redo the last operation.
     * @returns {boolean}
     */
    canRedo() {
        const ret = wasm.undomanager_canRedo(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Can undo the last operation.
     * @returns {boolean}
     */
    canUndo() {
        const ret = wasm.undomanager_canUndo(this.__wbg_ptr);
        return ret !== 0;
    }
    groupEnd() {
        wasm.undomanager_groupEnd(this.__wbg_ptr);
    }
    /**
     * Returns whether the UndoManager is currently paused.
     * @returns {boolean}
     */
    isPaused() {
        const ret = wasm.undomanager_isPaused(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Set the on pop event listener.
     *
     * Every time an undo step or redo step is popped, the on pop event listener will be called.
     * @param {any} on_pop
     */
    setOnPop(on_pop) {
        wasm.undomanager_setOnPop(this.__wbg_ptr, on_pop);
    }
    /**
     * Clear only the redo stack, preserving the undo stack.
     *
     * This is useful when coordinating undo/redo across multiple participants
     * (e.g., multiple editors) where a new edit in one participant should
     * invalidate redo in all other participants.
     */
    clearRedo() {
        wasm.undomanager_clearRedo(this.__wbg_ptr);
    }
    /**
     * Clear only the undo stack, preserving the redo stack.
     */
    clearUndo() {
        wasm.undomanager_clearUndo(this.__wbg_ptr);
    }
    /**
     * Set the on push event listener.
     *
     * Every time an undo step or redo step is pushed, the on push event listener will be called.
     * @param {any} on_push
     */
    setOnPush(on_push) {
        wasm.undomanager_setOnPush(this.__wbg_ptr, on_push);
    }
}
module.exports.UndoManager = UndoManager;

const VersionVectorFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_versionvector_free(ptr >>> 0, 1));
/**
 * [VersionVector](https://en.wikipedia.org/wiki/Version_vector)
 * is a map from [PeerID] to [Counter]. Its a right-open interval.
 *
 * i.e. a [VersionVector] of `{A: 1, B: 2}` means that A has 1 atomic op and B has 2 atomic ops,
 * thus ID of `{client: A, counter: 1}` is out of the range.
 */
class VersionVector {

    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(VersionVector.prototype);
        obj.__wbg_ptr = ptr;
        VersionVectorFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }

    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        VersionVectorFinalization.unregister(this);
        return ptr;
    }

    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_versionvector_free(ptr, 0);
    }
    /**
     * Get the counter of a peer.
     * @param {number | bigint | `${number}`} peer_id
     * @returns {number | undefined}
     */
    get(peer_id) {
        const ret = wasm.versionvector_get(this.__wbg_ptr, peer_id);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] === 0x100000001 ? undefined : ret[0];
    }
    /**
     * Create a new version vector.
     * @param {Map<PeerID, number> | Uint8Array | VersionVector | undefined | null} value
     */
    constructor(value) {
        const ret = wasm.versionvector_new(value);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0] >>> 0;
        VersionVectorFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Decode the version vector from a Uint8Array.
     * @param {Uint8Array} bytes
     * @returns {VersionVector}
     */
    static decode(bytes) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.versionvector_decode(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return VersionVector.__wrap(ret[0]);
    }
    /**
     * Encode the version vector into a Uint8Array.
     * @returns {Uint8Array}
     */
    encode() {
        const ret = wasm.versionvector_encode(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * @returns {number}
     */
    length() {
        const ret = wasm.versionvector_length(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * @param {PeerID} peer
     */
    remove(peer) {
        const ret = wasm.versionvector_remove(this.__wbg_ptr, peer);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * set the exclusive ending point. target id will NOT be included by self
     * @param {{ peer: PeerID, counter: number }} id
     */
    setEnd(id) {
        const ret = wasm.versionvector_setEnd(this.__wbg_ptr, id);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Compare the version vector with another version vector.
     *
     * If they are concurrent, return undefined.
     * @param {VersionVector} other
     * @returns {number | undefined}
     */
    compare(other) {
        _assertClass(other, VersionVector);
        const ret = wasm.versionvector_compare(this.__wbg_ptr, other.__wbg_ptr);
        return ret === 0x100000001 ? undefined : ret;
    }
    /**
     * set the inclusive ending point. target id will be included
     * @param {{ peer: PeerID, counter: number }} id
     */
    setLast(id) {
        const ret = wasm.versionvector_setLast(this.__wbg_ptr, id);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Convert the version vector to a Map
     * @returns {Map<PeerID, number>}
     */
    toJSON() {
        const ret = wasm.versionvector_toJSON(this.__wbg_ptr);
        return ret;
    }
    /**
     * Create a new version vector from a Map.
     * @param {Map<PeerID, number>} version
     * @returns {VersionVector}
     */
    static parseJSON(version) {
        const ret = wasm.versionvector_parseJSON(version);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return VersionVector.__wrap(ret[0]);
    }
}
module.exports.VersionVector = VersionVector;

module.exports.__wbg_String_8f0eb39a4a4c2f66 = function(arg0, arg1) {
    const ret = String(arg1);
    const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
};

module.exports.__wbg_apply_36be6a55257c99bf = function() { return handleError(function (arg0, arg1, arg2) {
    const ret = arg0.apply(arg1, arg2);
    return ret;
}, arguments) };

module.exports.__wbg_apply_eb9e9b97497f91e4 = function() { return handleError(function (arg0, arg1, arg2) {
    const ret = Reflect.apply(arg0, arg1, arg2);
    return ret;
}, arguments) };

module.exports.__wbg_buffer_609cc3eee51ed158 = function(arg0) {
    const ret = arg0.buffer;
    return ret;
};

module.exports.__wbg_call_672a4d21634d4a24 = function() { return handleError(function (arg0, arg1) {
    const ret = arg0.call(arg1);
    return ret;
}, arguments) };

module.exports.__wbg_call_7cccdd69e0791ae2 = function() { return handleError(function (arg0, arg1, arg2) {
    const ret = arg0.call(arg1, arg2);
    return ret;
}, arguments) };

module.exports.__wbg_call_833bed5770ea2041 = function() { return handleError(function (arg0, arg1, arg2, arg3) {
    const ret = arg0.call(arg1, arg2, arg3);
    return ret;
}, arguments) };

module.exports.__wbg_call_b8adc8b1d0a0d8eb = function() { return handleError(function (arg0, arg1, arg2, arg3, arg4) {
    const ret = arg0.call(arg1, arg2, arg3, arg4);
    return ret;
}, arguments) };

module.exports.__wbg_changemodifier_new = function(arg0) {
    const ret = ChangeModifier.__wrap(arg0);
    return ret;
};

module.exports.__wbg_crypto_574e78ad8b13b65f = function(arg0) {
    const ret = arg0.crypto;
    return ret;
};

module.exports.__wbg_cursor_new = function(arg0) {
    const ret = Cursor.__wrap(arg0);
    return ret;
};

module.exports.__wbg_done_769e5ede4b31c67b = function(arg0) {
    const ret = arg0.done;
    return ret;
};

module.exports.__wbg_entries_3265d4158b33e5dc = function(arg0) {
    const ret = Object.entries(arg0);
    return ret;
};

module.exports.__wbg_entries_c8a90a7ed73e84ce = function(arg0) {
    const ret = arg0.entries();
    return ret;
};

module.exports.__wbg_error_1d6f2b3f2c5a33ec = function(arg0, arg1) {
    console.error(getStringFromWasm0(arg0, arg1));
};

module.exports.__wbg_from_2a5d3e218e67aa85 = function(arg0) {
    const ret = Array.from(arg0);
    return ret;
};

module.exports.__wbg_getOwnPropertySymbols_97eebed6fe6e08be = function(arg0) {
    const ret = Object.getOwnPropertySymbols(arg0);
    return ret;
};

module.exports.__wbg_getRandomValues_b8f5dbd5f3995a9e = function() { return handleError(function (arg0, arg1) {
    arg0.getRandomValues(arg1);
}, arguments) };

module.exports.__wbg_get_67b2ba62fc30de12 = function() { return handleError(function (arg0, arg1) {
    const ret = Reflect.get(arg0, arg1);
    return ret;
}, arguments) };

module.exports.__wbg_get_b9b93047fe3cf45b = function(arg0, arg1) {
    const ret = arg0[arg1 >>> 0];
    return ret;
};

module.exports.__wbg_getindex_5b00c274b05714aa = function(arg0, arg1) {
    const ret = arg0[arg1 >>> 0];
    return ret;
};

module.exports.__wbg_getwithrefkey_1dc361bd10053bfe = function(arg0, arg1) {
    const ret = arg0[arg1];
    return ret;
};

module.exports.__wbg_instanceof_ArrayBuffer_e14585432e3737fc = function(arg0) {
    let result;
    try {
        result = arg0 instanceof ArrayBuffer;
    } catch (_) {
        result = false;
    }
    const ret = result;
    return ret;
};

module.exports.__wbg_instanceof_Map_f3469ce2244d2430 = function(arg0) {
    let result;
    try {
        result = arg0 instanceof Map;
    } catch (_) {
        result = false;
    }
    const ret = result;
    return ret;
};

module.exports.__wbg_instanceof_Object_7f2dcef8f78644a4 = function(arg0) {
    let result;
    try {
        result = arg0 instanceof Object;
    } catch (_) {
        result = false;
    }
    const ret = result;
    return ret;
};

module.exports.__wbg_instanceof_Uint8Array_17156bcf118086a9 = function(arg0) {
    let result;
    try {
        result = arg0 instanceof Uint8Array;
    } catch (_) {
        result = false;
    }
    const ret = result;
    return ret;
};

module.exports.__wbg_isArray_a1eab7e0d067391b = function(arg0) {
    const ret = Array.isArray(arg0);
    return ret;
};

module.exports.__wbg_isSafeInteger_343e2beeeece1bb0 = function(arg0) {
    const ret = Number.isSafeInteger(arg0);
    return ret;
};

module.exports.__wbg_iterator_9a24c88df860dc65 = function() {
    const ret = Symbol.iterator;
    return ret;
};

module.exports.__wbg_length_a446193dc22c12f8 = function(arg0) {
    const ret = arg0.length;
    return ret;
};

module.exports.__wbg_length_e2d2a49132c1b256 = function(arg0) {
    const ret = arg0.length;
    return ret;
};

module.exports.__wbg_log_0cc1b7768397bcfe = function(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7) {
    let deferred0_0;
    let deferred0_1;
    try {
        deferred0_0 = arg0;
        deferred0_1 = arg1;
        console.log(getStringFromWasm0(arg0, arg1), getStringFromWasm0(arg2, arg3), getStringFromWasm0(arg4, arg5), getStringFromWasm0(arg6, arg7));
    } finally {
        wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
    }
};

module.exports.__wbg_log_cb9e190acc5753fb = function(arg0, arg1) {
    let deferred0_0;
    let deferred0_1;
    try {
        deferred0_0 = arg0;
        deferred0_1 = arg1;
        console.log(getStringFromWasm0(arg0, arg1));
    } finally {
        wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
    }
};

module.exports.__wbg_log_f665cabe523a97df = function(arg0, arg1) {
    console.log(getStringFromWasm0(arg0, arg1));
};

module.exports.__wbg_lorocounter_new = function(arg0) {
    const ret = LoroCounter.__wrap(arg0);
    return ret;
};

module.exports.__wbg_lorolist_new = function(arg0) {
    const ret = LoroList.__wrap(arg0);
    return ret;
};

module.exports.__wbg_loromap_new = function(arg0) {
    const ret = LoroMap.__wrap(arg0);
    return ret;
};

module.exports.__wbg_loromovablelist_new = function(arg0) {
    const ret = LoroMovableList.__wrap(arg0);
    return ret;
};

module.exports.__wbg_lorotext_new = function(arg0) {
    const ret = LoroText.__wrap(arg0);
    return ret;
};

module.exports.__wbg_lorotree_new = function(arg0) {
    const ret = LoroTree.__wrap(arg0);
    return ret;
};

module.exports.__wbg_lorotreenode_new = function(arg0) {
    const ret = LoroTreeNode.__wrap(arg0);
    return ret;
};

module.exports.__wbg_mark_7438147ce31e9d4b = function(arg0, arg1) {
    performance.mark(getStringFromWasm0(arg0, arg1));
};

module.exports.__wbg_measure_fb7825c11612c823 = function() { return handleError(function (arg0, arg1, arg2, arg3) {
    let deferred0_0;
    let deferred0_1;
    let deferred1_0;
    let deferred1_1;
    try {
        deferred0_0 = arg0;
        deferred0_1 = arg1;
        deferred1_0 = arg2;
        deferred1_1 = arg3;
        performance.measure(getStringFromWasm0(arg0, arg1), getStringFromWasm0(arg2, arg3));
    } finally {
        wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
        wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
}, arguments) };

module.exports.__wbg_msCrypto_a61aeb35a24c1329 = function(arg0) {
    const ret = arg0.msCrypto;
    return ret;
};

module.exports.__wbg_new_405e22f390576ce2 = function() {
    const ret = new Object();
    return ret;
};

module.exports.__wbg_new_5e0be73521bc8c17 = function() {
    const ret = new Map();
    return ret;
};

module.exports.__wbg_new_78feb108b6472713 = function() {
    const ret = new Array();
    return ret;
};

module.exports.__wbg_new_a12002a7f91c75be = function(arg0) {
    const ret = new Uint8Array(arg0);
    return ret;
};

module.exports.__wbg_new_c68d7209be747379 = function(arg0, arg1) {
    const ret = new Error(getStringFromWasm0(arg0, arg1));
    return ret;
};

module.exports.__wbg_newnoargs_105ed471475aaf50 = function(arg0, arg1) {
    const ret = new Function(getStringFromWasm0(arg0, arg1));
    return ret;
};

module.exports.__wbg_newwithbyteoffsetandlength_d97e637ebe145a9a = function(arg0, arg1, arg2) {
    const ret = new Uint8Array(arg0, arg1 >>> 0, arg2 >>> 0);
    return ret;
};

module.exports.__wbg_newwithlength_a381634e90c276d4 = function(arg0) {
    const ret = new Uint8Array(arg0 >>> 0);
    return ret;
};

module.exports.__wbg_newwithlength_c4c419ef0bc8a1f8 = function(arg0) {
    const ret = new Array(arg0 >>> 0);
    return ret;
};

module.exports.__wbg_next_25feadfc0913fea9 = function(arg0) {
    const ret = arg0.next;
    return ret;
};

module.exports.__wbg_next_6574e1a8a62d1055 = function() { return handleError(function (arg0) {
    const ret = arg0.next();
    return ret;
}, arguments) };

module.exports.__wbg_node_905d3e251edff8a2 = function(arg0) {
    const ret = arg0.node;
    return ret;
};

module.exports.__wbg_now_454cbad00d40f177 = function() {
    const ret = Date.now();
    return ret;
};

module.exports.__wbg_ownKeys_3930041068756f1f = function() { return handleError(function (arg0) {
    const ret = Reflect.ownKeys(arg0);
    return ret;
}, arguments) };

module.exports.__wbg_process_dc0fbacc7c1c06f7 = function(arg0) {
    const ret = arg0.process;
    return ret;
};

module.exports.__wbg_push_737cfc8c1432c2c6 = function(arg0, arg1) {
    const ret = arg0.push(arg1);
    return ret;
};

module.exports.__wbg_randomFillSync_ac0988aba3254290 = function() { return handleError(function (arg0, arg1) {
    arg0.randomFillSync(arg1);
}, arguments) };

module.exports.__wbg_require_60cc747a6bc5215a = function() { return handleError(function () {
    const ret = module.require;
    return ret;
}, arguments) };

module.exports.__wbg_resolve_4851785c9c5f573d = function(arg0) {
    const ret = Promise.resolve(arg0);
    return ret;
};

module.exports.__wbg_set_37837023f3d740e8 = function(arg0, arg1, arg2) {
    arg0[arg1 >>> 0] = arg2;
};

module.exports.__wbg_set_3f1d0b984ed272ed = function(arg0, arg1, arg2) {
    arg0[arg1] = arg2;
};

module.exports.__wbg_set_65595bdd868b3009 = function(arg0, arg1, arg2) {
    arg0.set(arg1, arg2 >>> 0);
};

module.exports.__wbg_set_8fc6bf8a5b1071d1 = function(arg0, arg1, arg2) {
    const ret = arg0.set(arg1, arg2);
    return ret;
};

module.exports.__wbg_set_bb8cecf6a62b9f46 = function() { return handleError(function (arg0, arg1, arg2) {
    const ret = Reflect.set(arg0, arg1, arg2);
    return ret;
}, arguments) };

module.exports.__wbg_setindex_dcd71eabf405bde1 = function(arg0, arg1, arg2) {
    arg0[arg1 >>> 0] = arg2;
};

module.exports.__wbg_stateBinary_9e1da8a4daa74bc6 = function(arg0, arg1) {
    const ret = stateBinary(getArrayU8FromWasm0(arg0, arg1));
    return ret;
};

module.exports.__wbg_stateIndex_1fbac6394e58cff9 = function() { return handleError(function (arg0, arg1, arg2) {
    stateIndex(arg0, arg1 >>> 0, arg2);
}, arguments) };

module.exports.__wbg_stateOptions_dcb483514d1b925d = function() { return handleError(function (arg0, arg1) {
    const ret = stateOptions(arg0, arg1 !== 0);
    return ret;
}, arguments) };

module.exports.__wbg_stateRootCid_9198769cdd9f37d5 = function(arg0, arg1, arg2) {
    const ret = stateRootCid(getStringFromWasm0(arg0, arg1), arg2);
    return ret;
};

module.exports.__wbg_stateSet_a3e74b27d3d26f9d = function() { return handleError(function (arg0, arg1, arg2) {
    stateSet(arg0, arg1, arg2);
}, arguments) };

module.exports.__wbg_stateSlice_aafffe8ecba122b8 = function(arg0, arg1, arg2) {
    const ret = stateSlice(arg0, arg1 >>> 0, arg2 >>> 0);
    return ret;
};

module.exports.__wbg_static_accessor_GLOBAL_88a902d13a557d07 = function() {
    const ret = typeof global === 'undefined' ? null : global;
    return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
};

module.exports.__wbg_static_accessor_GLOBAL_THIS_56578be7e9f832b0 = function() {
    const ret = typeof globalThis === 'undefined' ? null : globalThis;
    return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
};

module.exports.__wbg_static_accessor_SELF_37c5d418e4bf5819 = function() {
    const ret = typeof self === 'undefined' ? null : self;
    return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
};

module.exports.__wbg_static_accessor_WINDOW_5de37043a91a9c40 = function() {
    const ret = typeof window === 'undefined' ? null : window;
    return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
};

module.exports.__wbg_subarray_aa9065fa9dc5df96 = function(arg0, arg1, arg2) {
    const ret = arg0.subarray(arg1 >>> 0, arg2 >>> 0);
    return ret;
};

module.exports.__wbg_then_44b73946d2fb3e7d = function(arg0, arg1) {
    const ret = arg0.then(arg1);
    return ret;
};

module.exports.__wbg_value_cd1ffa7b1ab794f1 = function(arg0) {
    const ret = arg0.value;
    return ret;
};

module.exports.__wbg_versions_c01dfd4722a88165 = function(arg0) {
    const ret = arg0.versions;
    return ret;
};

module.exports.__wbg_versionvector_new = function(arg0) {
    const ret = VersionVector.__wrap(arg0);
    return ret;
};

module.exports.__wbg_warn_52b319b1b6be3d2f = function(arg0, arg1) {
    console.warn(getStringFromWasm0(arg0, arg1));
};

module.exports.__wbindgen_as_number = function(arg0) {
    const ret = +arg0;
    return ret;
};

module.exports.__wbindgen_bigint_from_i64 = function(arg0) {
    const ret = arg0;
    return ret;
};

module.exports.__wbindgen_bigint_from_u64 = function(arg0) {
    const ret = BigInt.asUintN(64, arg0);
    return ret;
};

module.exports.__wbindgen_bigint_get_as_i64 = function(arg0, arg1) {
    const v = arg1;
    const ret = typeof(v) === 'bigint' ? v : undefined;
    getDataViewMemory0().setBigInt64(arg0 + 8 * 1, isLikeNone(ret) ? BigInt(0) : ret, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
};

module.exports.__wbindgen_boolean_get = function(arg0) {
    const v = arg0;
    const ret = typeof(v) === 'boolean' ? (v ? 1 : 0) : 2;
    return ret;
};

module.exports.__wbindgen_cb_drop = function(arg0) {
    const obj = arg0.original;
    if (obj.cnt-- == 1) {
        obj.a = 0;
        return true;
    }
    const ret = false;
    return ret;
};

module.exports.__wbindgen_closure_wrapper1226 = function(arg0, arg1, arg2) {
    const ret = makeMutClosure(arg0, arg1, 160, __wbg_adapter_60);
    return ret;
};

module.exports.__wbindgen_closure_wrapper1228 = function(arg0, arg1, arg2) {
    const ret = makeMutClosure(arg0, arg1, 160, __wbg_adapter_63);
    return ret;
};

module.exports.__wbindgen_debug_string = function(arg0, arg1) {
    const ret = debugString(arg1);
    const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
};

module.exports.__wbindgen_error_new = function(arg0, arg1) {
    const ret = new Error(getStringFromWasm0(arg0, arg1));
    return ret;
};

module.exports.__wbindgen_in = function(arg0, arg1) {
    const ret = arg0 in arg1;
    return ret;
};

module.exports.__wbindgen_init_externref_table = function() {
    const table = wasm.__wbindgen_export_4;
    const offset = table.grow(4);
    table.set(0, undefined);
    table.set(offset + 0, undefined);
    table.set(offset + 1, null);
    table.set(offset + 2, true);
    table.set(offset + 3, false);
    ;
};

module.exports.__wbindgen_is_array = function(arg0) {
    const ret = Array.isArray(arg0);
    return ret;
};

module.exports.__wbindgen_is_bigint = function(arg0) {
    const ret = typeof(arg0) === 'bigint';
    return ret;
};

module.exports.__wbindgen_is_function = function(arg0) {
    const ret = typeof(arg0) === 'function';
    return ret;
};

module.exports.__wbindgen_is_null = function(arg0) {
    const ret = arg0 === null;
    return ret;
};

module.exports.__wbindgen_is_object = function(arg0) {
    const val = arg0;
    const ret = typeof(val) === 'object' && val !== null;
    return ret;
};

module.exports.__wbindgen_is_string = function(arg0) {
    const ret = typeof(arg0) === 'string';
    return ret;
};

module.exports.__wbindgen_is_undefined = function(arg0) {
    const ret = arg0 === undefined;
    return ret;
};

module.exports.__wbindgen_jsval_eq = function(arg0, arg1) {
    const ret = arg0 === arg1;
    return ret;
};

module.exports.__wbindgen_jsval_loose_eq = function(arg0, arg1) {
    const ret = arg0 == arg1;
    return ret;
};

module.exports.__wbindgen_memory = function() {
    const ret = wasm.memory;
    return ret;
};

module.exports.__wbindgen_number_get = function(arg0, arg1) {
    const obj = arg1;
    const ret = typeof(obj) === 'number' ? obj : undefined;
    getDataViewMemory0().setFloat64(arg0 + 8 * 1, isLikeNone(ret) ? 0 : ret, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
};

module.exports.__wbindgen_number_new = function(arg0) {
    const ret = arg0;
    return ret;
};

module.exports.__wbindgen_rethrow = function(arg0) {
    throw arg0;
};

module.exports.__wbindgen_string_get = function(arg0, arg1) {
    const obj = arg1;
    const ret = typeof(obj) === 'string' ? obj : undefined;
    var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    var len1 = WASM_VECTOR_LEN;
    getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
    getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
};

module.exports.__wbindgen_string_new = function(arg0, arg1) {
    const ret = getStringFromWasm0(arg0, arg1);
    return ret;
};

module.exports.__wbindgen_throw = function(arg0, arg1) {
    throw new Error(getStringFromWasm0(arg0, arg1));
};

module.exports.__wbindgen_typeof = function(arg0) {
    const ret = typeof arg0;
    return ret;
};

const path = require('path').join(__dirname, 'loro_wasm_bg.wasm');
const bytes = require('fs').readFileSync(path);

const wasmModule = new WebAssembly.Module(bytes);
const wasmInstance = new WebAssembly.Instance(wasmModule, imports);
wasm = wasmInstance.exports;
module.exports.__wasm = wasm;

wasm.__wbindgen_start();


// A container handler never changes identity during one JS wrapper's lifetime.
// Attaching a detached handler returns a different wrapper, and getAttached()
// also returns a new wrapper. Cache on the wrapper, not by container id.
const __loroContainerIdCache = Symbol("loroContainerId");

function __loroCacheContainerIdGetter(ContainerClass) {
  const prototype = ContainerClass.prototype;
  const idDescriptor = Object.getOwnPropertyDescriptor(prototype, "id");
  const getId = idDescriptor && idDescriptor.get;
  const destroyDescriptor = Object.getOwnPropertyDescriptor(
    prototype,
    "__destroy_into_raw",
  );
  const destroy = destroyDescriptor && destroyDescriptor.value;

  if (!getId || !destroyDescriptor || !destroy) {
    throw new Error("Unexpected wasm-bindgen container wrapper shape");
  }

  Object.defineProperty(prototype, "id", {
    ...idDescriptor,
    get() {
      // Preserve wasm-bindgen's post-free error instead of returning stale data.
      if (this.__wbg_ptr === 0) {
        return getId.call(this);
      }

      const cached = this[__loroContainerIdCache];
      if (cached !== undefined) {
        return cached;
      }

      const id = getId.call(this);
      try {
        Object.defineProperty(this, __loroContainerIdCache, {
          configurable: true,
          value: id,
        });
      } catch {
        // Caching must not make a non-extensible wrapper's id unreadable.
      }
      return id;
    },
  });

  Object.defineProperty(prototype, "__destroy_into_raw", {
    ...destroyDescriptor,
    value() {
      try {
        delete this[__loroContainerIdCache];
      } catch {
        // Cache cleanup must not replace wasm-bindgen's free behavior.
      }
      return destroy.call(this);
    },
  });
}

// `kind()` returns a constant string per container class and never depends on
// instance state, so one module-level memo per class is enough. Repeated reads
// (e.g. loro-mirror's traversal) must not cross into WASM again.
function __loroCacheKindMethod(ContainerClass) {
  const prototype = ContainerClass.prototype;
  const kindDescriptor = Object.getOwnPropertyDescriptor(prototype, "kind");
  const kind = kindDescriptor && kindDescriptor.value;

  if (typeof kind !== "function") {
    throw new Error("Unexpected wasm-bindgen container wrapper shape");
  }

  let cached;
  Object.defineProperty(prototype, "kind", {
    ...kindDescriptor,
    value() {
      // Preserve wasm-bindgen's post-free error instead of returning stale data.
      if (this.__wbg_ptr === 0) {
        return kind.call(this);
      }

      if (cached === undefined) {
        cached = kind.call(this);
      }
      return cached;
    },
  });
}

for (const ContainerClass of [
  LoroMap,
  LoroText,
  LoroList,
  LoroTree,
  LoroMovableList,
  LoroCounter,
]) {
  __loroCacheContainerIdGetter(ContainerClass);
  __loroCacheKindMethod(ContainerClass);
}

// Don't patch this if it already exists (for example in Deno)
if (!globalThis.crypto) {
    // We need this patch because we use `getrandom` crate in Rust, which relies on this patch 
    // for nodejs
    // https://docs.rs/getrandom/latest/getrandom/#nodejs-es-module-support
    const { webcrypto } = require("crypto");
    Object.defineProperty(globalThis, 'crypto', {
        value: webcrypto,
        writable: true
    });
}
